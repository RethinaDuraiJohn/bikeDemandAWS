# Predict Bike Sharing Demand with AutoGluon Template

## Project: Predict Bike Sharing Demand with AutoGluon
This notebook is a template with each step that you need to complete for the project.

Please fill in your code where there are explicit `?` markers in the notebook. You are welcome to add more cells and code as you see fit.

Once you have completed all the code implementations, please export your notebook as a HTML file so the reviews can view your code. Make sure you have all outputs correctly outputted.

`File-> Export Notebook As... -> Export Notebook as HTML`

There is a writeup to complete as well after all code implememtation is done. Please answer all questions and attach the necessary tables and charts. You can complete the writeup in either markdown or PDF.

Completing the code template and writeup template will cover all of the rubric points for this project.

The rubric contains "Stand Out Suggestions" for enhancing the project beyond the minimum requirements. The stand out suggestions are optional. If you decide to pursue the "stand out suggestions", you can include the code in this notebook and also discuss the results in the writeup file.

## Step 1: Create an account with Kaggle

### Create Kaggle Account and download API key
Below is example of steps to get the API username and key. Each student will have their own username and key.

1. Open account settings.
![kaggle1.png](attachment:kaggle1.png)
![kaggle2.png](attachment:kaggle2.png)
2. Scroll down to API and click Create New API Token.
![kaggle3.png](attachment:kaggle3.png)
![kaggle4.png](attachment:kaggle4.png)
3. Open up `kaggle.json` and use the username and key.
![kaggle5.png](attachment:kaggle5.png)

## Step 2: Download the Kaggle dataset using the kaggle python library

### Open up Sagemaker Studio and use starter template

1. Notebook should be using a `ml.t3.medium` instance (2 vCPU + 4 GiB)
2. Notebook should be using kernal: `Python 3 (MXNet 1.8 Python 3.7 CPU Optimized)`

### Install packages


```python
!pip install -U pip
!pip install -U setuptools wheel
!pip install -U "mxnet<2.0.0" bokeh==2.0.1
!pip install autogluon --no-cache-dir
# Without --no-cache-dir, smaller aws instances may have trouble installing
```

    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: pip in /usr/local/lib/python3.8/dist-packages (21.1.3)
    Collecting pip
      Downloading pip-22.3.1-py3-none-any.whl (2.1 MB)
    [K     |████████████████████████████████| 2.1 MB 31.3 MB/s 
    [?25hInstalling collected packages: pip
      Attempting uninstall: pip
        Found existing installation: pip 21.1.3
        Uninstalling pip-21.1.3:
          Successfully uninstalled pip-21.1.3
    Successfully installed pip-22.3.1
    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: setuptools in /usr/local/lib/python3.8/dist-packages (57.4.0)
    Collecting setuptools
      Downloading setuptools-65.6.3-py3-none-any.whl (1.2 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.2/1.2 MB[0m [31m28.3 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: wheel in /usr/local/lib/python3.8/dist-packages (0.38.4)
    Installing collected packages: setuptools
      Attempting uninstall: setuptools
        Found existing installation: setuptools 57.4.0
        Uninstalling setuptools-57.4.0:
          Successfully uninstalled setuptools-57.4.0
    [31mERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    ipython 7.9.0 requires jedi>=0.10, which is not installed.[0m[31m
    [0mSuccessfully installed setuptools-65.6.3
    [33mWARNING: Running pip as the 'root' user can result in broken permissions and conflicting behaviour with the system package manager. It is recommended to use a virtual environment instead: https://pip.pypa.io/warnings/venv[0m[33m
    [0mLooking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Collecting mxnet<2.0.0
      Downloading mxnet-1.9.1-py3-none-manylinux2014_x86_64.whl (49.1 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m49.1/49.1 MB[0m [31m12.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting bokeh==2.0.1
      Downloading bokeh-2.0.1.tar.gz (8.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m8.6/8.6 MB[0m [31m17.8 MB/s[0m eta [36m0:00:00[0m
    [?25h  Preparing metadata (setup.py) ... [?25l[?25hdone
    Requirement already satisfied: PyYAML>=3.10 in /usr/local/lib/python3.8/dist-packages (from bokeh==2.0.1) (6.0)
    Requirement already satisfied: python-dateutil>=2.1 in /usr/local/lib/python3.8/dist-packages (from bokeh==2.0.1) (2.8.2)
    Requirement already satisfied: Jinja2>=2.7 in /usr/local/lib/python3.8/dist-packages (from bokeh==2.0.1) (2.11.3)
    Requirement already satisfied: numpy>=1.11.3 in /usr/local/lib/python3.8/dist-packages (from bokeh==2.0.1) (1.21.6)
    Requirement already satisfied: pillow>=4.0 in /usr/local/lib/python3.8/dist-packages (from bokeh==2.0.1) (7.1.2)
    Requirement already satisfied: packaging>=16.8 in /usr/local/lib/python3.8/dist-packages (from bokeh==2.0.1) (21.3)
    Requirement already satisfied: tornado>=5 in /usr/local/lib/python3.8/dist-packages (from bokeh==2.0.1) (6.0.4)
    Requirement already satisfied: typing_extensions>=3.7.4 in /usr/local/lib/python3.8/dist-packages (from bokeh==2.0.1) (4.4.0)
    Collecting graphviz<0.9.0,>=0.8.1
      Downloading graphviz-0.8.4-py2.py3-none-any.whl (16 kB)
    Requirement already satisfied: requests<3,>=2.20.0 in /usr/local/lib/python3.8/dist-packages (from mxnet<2.0.0) (2.23.0)
    Requirement already satisfied: MarkupSafe>=0.23 in /usr/local/lib/python3.8/dist-packages (from Jinja2>=2.7->bokeh==2.0.1) (2.0.1)
    Requirement already satisfied: pyparsing!=3.0.5,>=2.0.2 in /usr/local/lib/python3.8/dist-packages (from packaging>=16.8->bokeh==2.0.1) (3.0.9)
    Requirement already satisfied: six>=1.5 in /usr/local/lib/python3.8/dist-packages (from python-dateutil>=2.1->bokeh==2.0.1) (1.15.0)
    Requirement already satisfied: chardet<4,>=3.0.2 in /usr/local/lib/python3.8/dist-packages (from requests<3,>=2.20.0->mxnet<2.0.0) (3.0.4)
    Requirement already satisfied: certifi>=2017.4.17 in /usr/local/lib/python3.8/dist-packages (from requests<3,>=2.20.0->mxnet<2.0.0) (2022.12.7)
    Requirement already satisfied: urllib3!=1.25.0,!=1.25.1,<1.26,>=1.21.1 in /usr/local/lib/python3.8/dist-packages (from requests<3,>=2.20.0->mxnet<2.0.0) (1.24.3)
    Requirement already satisfied: idna<3,>=2.5 in /usr/local/lib/python3.8/dist-packages (from requests<3,>=2.20.0->mxnet<2.0.0) (2.10)
    Building wheels for collected packages: bokeh
      Building wheel for bokeh (setup.py) ... [?25l[?25hdone
      Created wheel for bokeh: filename=bokeh-2.0.1-py3-none-any.whl size=9080017 sha256=585891601739bc5625bb12f3be0950af8a53e8e4b4cdfe1056314a88487ba6ee
      Stored in directory: /root/.cache/pip/wheels/df/5e/9c/8bd156f0e272ecafaf8084bf6bd69ccb317e6fe6105edba7b2
    Successfully built bokeh
    Installing collected packages: graphviz, mxnet, bokeh
      Attempting uninstall: graphviz
        Found existing installation: graphviz 0.10.1
        Uninstalling graphviz-0.10.1:
          Successfully uninstalled graphviz-0.10.1
      Attempting uninstall: bokeh
        Found existing installation: bokeh 2.3.3
        Uninstalling bokeh-2.3.3:
          Successfully uninstalled bokeh-2.3.3
    [31mERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    panel 0.12.1 requires bokeh<2.4.0,>=2.3.0, but you have bokeh 2.0.1 which is incompatible.[0m[31m
    [0mSuccessfully installed bokeh-2.0.1 graphviz-0.8.4 mxnet-1.9.1
    [33mWARNING: Running pip as the 'root' user can result in broken permissions and conflicting behaviour with the system package manager. It is recommended to use a virtual environment instead: https://pip.pypa.io/warnings/venv[0m[33m
    [0mLooking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Collecting autogluon
      Downloading autogluon-0.6.1-py3-none-any.whl (9.8 kB)
    Collecting autogluon.features==0.6.1
      Downloading autogluon.features-0.6.1-py3-none-any.whl (59 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m60.0/60.0 kB[0m [31m209.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.timeseries[all]==0.6.1
      Downloading autogluon.timeseries-0.6.1-py3-none-any.whl (103 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m103.0/103.0 kB[0m [31m282.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.tabular[all]==0.6.1
      Downloading autogluon.tabular-0.6.1-py3-none-any.whl (286 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m286.0/286.0 kB[0m [31m307.9 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.text==0.6.1
      Downloading autogluon.text-0.6.1-py3-none-any.whl (62 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m62.1/62.1 kB[0m [31m254.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.multimodal==0.6.1
      Downloading autogluon.multimodal-0.6.1-py3-none-any.whl (289 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m289.7/289.7 kB[0m [31m188.9 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.vision==0.6.1
      Downloading autogluon.vision-0.6.1-py3-none-any.whl (49 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m49.8/49.8 kB[0m [31m221.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.core[all]==0.6.1
      Downloading autogluon.core-0.6.1-py3-none-any.whl (226 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m226.6/226.6 kB[0m [31m312.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting autogluon.common==0.6.1
      Downloading autogluon.common-0.6.1-py3-none-any.whl (41 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m41.5/41.5 kB[0m [31m193.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting boto3
      Downloading boto3-1.26.39-py3-none-any.whl (132 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m132.7/132.7 kB[0m [31m247.9 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting dask<=2021.11.2,>=2021.09.1
      Downloading dask-2021.11.2-py3-none-any.whl (1.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.0/1.0 MB[0m [31m310.1 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: pandas!=1.4.0,<1.6,>=1.2.5 in /usr/local/lib/python3.8/dist-packages (from autogluon.core[all]==0.6.1->autogluon) (1.3.5)
    Requirement already satisfied: scikit-learn<1.2,>=1.0.0 in /usr/local/lib/python3.8/dist-packages (from autogluon.core[all]==0.6.1->autogluon) (1.0.2)
    Collecting distributed<=2021.11.2,>=2021.09.1
      Downloading distributed-2021.11.2-py3-none-any.whl (802 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m802.2/802.2 kB[0m [31m348.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: scipy<1.10.0,>=1.5.4 in /usr/local/lib/python3.8/dist-packages (from autogluon.core[all]==0.6.1->autogluon) (1.7.3)
    Requirement already satisfied: tqdm>=4.38.0 in /usr/local/lib/python3.8/dist-packages (from autogluon.core[all]==0.6.1->autogluon) (4.64.1)
    Requirement already satisfied: numpy<1.24,>=1.21 in /usr/local/lib/python3.8/dist-packages (from autogluon.core[all]==0.6.1->autogluon) (1.21.6)
    Requirement already satisfied: matplotlib in /usr/local/lib/python3.8/dist-packages (from autogluon.core[all]==0.6.1->autogluon) (3.2.2)
    Requirement already satisfied: requests in /usr/local/lib/python3.8/dist-packages (from autogluon.core[all]==0.6.1->autogluon) (2.23.0)
    Collecting ray[tune]<2.1,>=2.0
      Downloading ray-2.0.1-cp38-cp38-manylinux2014_x86_64.whl (60.2 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m60.2/60.2 MB[0m [31m133.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting hyperopt<0.2.8,>=0.2.7
      Downloading hyperopt-0.2.7-py2.py3-none-any.whl (1.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.6/1.6 MB[0m [31m331.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting psutil<6,>=5.7.3
      Downloading psutil-5.9.4-cp36-abi3-manylinux_2_12_x86_64.manylinux2010_x86_64.manylinux_2_17_x86_64.manylinux2014_x86_64.whl (280 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m280.2/280.2 kB[0m [31m332.5 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting pytorch-metric-learning<1.4.0,>=1.3.0
      Downloading pytorch_metric_learning-1.3.2-py3-none-any.whl (109 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m109.4/109.4 kB[0m [31m250.2 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting torchvision<0.14.0
      Downloading torchvision-0.13.1-cp38-cp38-manylinux1_x86_64.whl (19.1 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m19.1/19.1 MB[0m [31m122.0 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting evaluate<=0.3.0
      Downloading evaluate-0.3.0-py3-none-any.whl (72 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m72.9/72.9 kB[0m [31m210.5 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting timm<0.7.0
      Downloading timm-0.6.12-py3-none-any.whl (549 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m549.1/549.1 kB[0m [31m334.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting nlpaug<=1.1.10,>=1.1.10
      Downloading nlpaug-1.1.10-py3-none-any.whl (410 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m410.8/410.8 kB[0m [31m330.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting sentencepiece<0.2.0,>=0.1.95
      Downloading sentencepiece-0.1.97-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (1.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.3/1.3 MB[0m [31m330.5 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting Pillow<=9.4.0,>=9.3.0
      Downloading Pillow-9.3.0-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (3.2 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m3.2/3.2 MB[0m [31m321.9 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting openmim<=0.2.1,>0.1.5
      Downloading openmim-0.2.1-py2.py3-none-any.whl (49 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m49.7/49.7 kB[0m [31m191.5 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting nptyping<1.5.0,>=1.4.4
      Downloading nptyping-1.4.4-py3-none-any.whl (31 kB)
    Collecting omegaconf<2.2.0,>=2.1.1
      Downloading omegaconf-2.1.2-py3-none-any.whl (74 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m74.7/74.7 kB[0m [31m148.1 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: text-unidecode<=1.3 in /usr/local/lib/python3.8/dist-packages (from autogluon.multimodal==0.6.1->autogluon) (1.3)
    Collecting torch<1.13,>=1.9
      Downloading torch-1.12.1-cp38-cp38-manylinux1_x86_64.whl (776.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m776.3/776.3 MB[0m [31m245.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting torchtext<0.14.0
      Downloading torchtext-0.13.1-cp38-cp38-manylinux1_x86_64.whl (1.9 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.9/1.9 MB[0m [31m343.5 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting transformers<4.24.0,>=4.23.0
      Downloading transformers-4.23.1-py3-none-any.whl (5.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m5.3/5.3 MB[0m [31m277.9 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting accelerate<0.14,>=0.9
      Downloading accelerate-0.13.2-py3-none-any.whl (148 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m148.8/148.8 kB[0m [31m179.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting seqeval<=1.2.2
      Downloading seqeval-1.2.2.tar.gz (43 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m43.6/43.6 kB[0m [31m153.8 MB/s[0m eta [36m0:00:00[0m
    [?25h  Preparing metadata (setup.py) ... [?25l[?25hdone
    Collecting scikit-image<0.20.0,>=0.19.1
      Downloading scikit_image-0.19.3-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (14.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m14.0/14.0 MB[0m [31m191.2 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting torchmetrics<0.9.0,>=0.8.0
      Downloading torchmetrics-0.8.2-py3-none-any.whl (409 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m409.8/409.8 kB[0m [31m142.7 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: nltk<4.0.0,>=3.4.5 in /usr/local/lib/python3.8/dist-packages (from autogluon.multimodal==0.6.1->autogluon) (3.7)
    Collecting fairscale<=0.4.6,>=0.4.5
      Downloading fairscale-0.4.6.tar.gz (248 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m248.2/248.2 kB[0m [31m296.4 MB/s[0m eta [36m0:00:00[0m
    [?25h  Installing build dependencies ... [?25l[?25hdone
      Getting requirements to build wheel ... [?25l[?25hdone
      Installing backend dependencies ... [?25l[?25hdone
      Preparing metadata (pyproject.toml) ... [?25l[?25hdone
    Collecting albumentations<=1.2.0,>=1.1.0
      Downloading albumentations-1.2.0-py3-none-any.whl (113 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m113.5/113.5 kB[0m [31m285.1 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting pytorch-lightning<1.8.0,>=1.7.4
      Downloading pytorch_lightning-1.7.7-py3-none-any.whl (708 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m708.1/708.1 kB[0m [31m312.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting smart-open<5.3.0,>=5.2.1
      Downloading smart_open-5.2.1-py3-none-any.whl (58 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m58.6/58.6 kB[0m [31m259.7 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: defusedxml<=0.7.1,>=0.7.1 in /usr/local/lib/python3.8/dist-packages (from autogluon.multimodal==0.6.1->autogluon) (0.7.1)
    Requirement already satisfied: jsonschema<=4.8.0 in /usr/local/lib/python3.8/dist-packages (from autogluon.multimodal==0.6.1->autogluon) (4.3.3)
    Requirement already satisfied: networkx<3.0,>=2.3 in /usr/local/lib/python3.8/dist-packages (from autogluon.tabular[all]==0.6.1->autogluon) (2.8.8)
    Collecting lightgbm<3.4,>=3.3
      Downloading lightgbm-3.3.3-py3-none-manylinux1_x86_64.whl (2.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m2.0/2.0 MB[0m [31m307.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting xgboost<1.8,>=1.6
      Downloading xgboost-1.7.2-py3-none-manylinux2014_x86_64.whl (193.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m193.6/193.6 MB[0m [31m213.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: fastai<2.8,>=2.3.1 in /usr/local/lib/python3.8/dist-packages (from autogluon.tabular[all]==0.6.1->autogluon) (2.7.10)
    Collecting catboost<1.2,>=1.0
      Downloading catboost-1.1.1-cp38-none-manylinux1_x86_64.whl (76.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m76.6/76.6 MB[0m [31m277.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting gluonts~=0.11.0
      Downloading gluonts-0.11.6-py3-none-any.whl (1.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.0/1.0 MB[0m [31m332.5 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: joblib~=1.1 in /usr/local/lib/python3.8/dist-packages (from autogluon.timeseries[all]==0.6.1->autogluon) (1.2.0)
    Collecting statsmodels~=0.13.0
      Downloading statsmodels-0.13.5-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (9.9 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m9.9/9.9 MB[0m [31m303.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting psutil<6,>=5.7.3
      Downloading psutil-5.8.0-cp38-cp38-manylinux2010_x86_64.whl (296 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m296.0/296.0 kB[0m [31m189.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting pmdarima~=1.8.2
      Downloading pmdarima-1.8.5-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.manylinux_2_24_x86_64.whl (1.5 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.5/1.5 MB[0m [31m310.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting sktime<0.14,>=0.13.1
      Downloading sktime-0.13.4-py3-none-any.whl (7.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m7.0/7.0 MB[0m [31m208.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting tbats~=1.1
      Downloading tbats-1.1.2-py3-none-any.whl (43 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m43.8/43.8 kB[0m [31m203.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting gluoncv<0.10.6,>=0.10.5
      Downloading gluoncv-0.10.5.post0-py2.py3-none-any.whl (1.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.3/1.3 MB[0m [31m35.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: setuptools in /usr/local/lib/python3.8/dist-packages (from autogluon.common==0.6.1->autogluon.core[all]==0.6.1->autogluon) (65.6.3)
    Requirement already satisfied: pyyaml in /usr/local/lib/python3.8/dist-packages (from accelerate<0.14,>=0.9->autogluon.multimodal==0.6.1->autogluon) (6.0)
    Requirement already satisfied: packaging>=20.0 in /usr/local/lib/python3.8/dist-packages (from accelerate<0.14,>=0.9->autogluon.multimodal==0.6.1->autogluon) (21.3)
    Collecting albumentations<=1.2.0,>=1.1.0
      Downloading albumentations-1.1.0-py3-none-any.whl (102 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m102.4/102.4 kB[0m [31m247.1 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: opencv-python-headless>=4.1.1 in /usr/local/lib/python3.8/dist-packages (from albumentations<=1.2.0,>=1.1.0->autogluon.multimodal==0.6.1->autogluon) (4.6.0.66)
    Requirement already satisfied: qudida>=0.0.4 in /usr/local/lib/python3.8/dist-packages (from albumentations<=1.2.0,>=1.1.0->autogluon.multimodal==0.6.1->autogluon) (0.0.4)
    Requirement already satisfied: graphviz in /usr/local/lib/python3.8/dist-packages (from catboost<1.2,>=1.0->autogluon.tabular[all]==0.6.1->autogluon) (0.8.4)
    Requirement already satisfied: plotly in /usr/local/lib/python3.8/dist-packages (from catboost<1.2,>=1.0->autogluon.tabular[all]==0.6.1->autogluon) (5.5.0)
    Requirement already satisfied: six in /usr/local/lib/python3.8/dist-packages (from catboost<1.2,>=1.0->autogluon.tabular[all]==0.6.1->autogluon) (1.15.0)
    Requirement already satisfied: cloudpickle>=1.1.1 in /usr/local/lib/python3.8/dist-packages (from dask<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (1.5.0)
    Requirement already satisfied: fsspec>=0.6.0 in /usr/local/lib/python3.8/dist-packages (from dask<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (2022.11.0)
    Requirement already satisfied: partd>=0.3.10 in /usr/local/lib/python3.8/dist-packages (from dask<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (1.3.0)
    Requirement already satisfied: toolz>=0.8.2 in /usr/local/lib/python3.8/dist-packages (from dask<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (0.12.0)
    Requirement already satisfied: msgpack>=0.6.0 in /usr/local/lib/python3.8/dist-packages (from distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (1.0.4)
    Requirement already satisfied: tornado>=6.0.3 in /usr/local/lib/python3.8/dist-packages (from distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (6.0.4)
    Requirement already satisfied: zict>=0.1.3 in /usr/local/lib/python3.8/dist-packages (from distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (2.2.0)
    Requirement already satisfied: sortedcontainers!=2.0.0,!=2.0.1 in /usr/local/lib/python3.8/dist-packages (from distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (2.4.0)
    Requirement already satisfied: tblib>=1.6.0 in /usr/local/lib/python3.8/dist-packages (from distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (1.7.0)
    Requirement already satisfied: click>=6.6 in /usr/local/lib/python3.8/dist-packages (from distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (7.1.2)
    Requirement already satisfied: jinja2 in /usr/local/lib/python3.8/dist-packages (from distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (2.11.3)
    Requirement already satisfied: dill in /usr/local/lib/python3.8/dist-packages (from evaluate<=0.3.0->autogluon.multimodal==0.6.1->autogluon) (0.3.6)
    Collecting xxhash
      Downloading xxhash-3.2.0-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (213 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m213.0/213.0 kB[0m [31m323.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting multiprocess
      Downloading multiprocess-0.70.14-py38-none-any.whl (132 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m132.0/132.0 kB[0m [31m225.7 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting datasets>=2.0.0
      Downloading datasets-2.8.0-py3-none-any.whl (452 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m452.9/452.9 kB[0m [31m319.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting responses<0.19
      Downloading responses-0.18.0-py3-none-any.whl (38 kB)
    Collecting huggingface-hub>=0.7.0
      Downloading huggingface_hub-0.11.1-py3-none-any.whl (182 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m182.4/182.4 kB[0m [31m270.5 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: spacy<4 in /usr/local/lib/python3.8/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (3.4.4)
    Requirement already satisfied: fastprogress>=0.2.4 in /usr/local/lib/python3.8/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (1.0.3)
    Requirement already satisfied: fastdownload<2,>=0.0.5 in /usr/local/lib/python3.8/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (0.0.7)
    Requirement already satisfied: pip in /usr/local/lib/python3.8/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (22.3.1)
    Requirement already satisfied: fastcore<1.6,>=1.4.5 in /usr/local/lib/python3.8/dist-packages (from fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (1.5.27)
    Collecting autocfg
      Downloading autocfg-0.0.8-py3-none-any.whl (13 kB)
    Collecting yacs
      Downloading yacs-0.1.8-py3-none-any.whl (14 kB)
    Requirement already satisfied: opencv-python in /usr/local/lib/python3.8/dist-packages (from gluoncv<0.10.6,>=0.10.5->autogluon.vision==0.6.1->autogluon) (4.6.0.66)
    Collecting portalocker
      Downloading portalocker-2.6.0-py2.py3-none-any.whl (15 kB)
    Requirement already satisfied: typing-extensions~=4.0 in /usr/local/lib/python3.8/dist-packages (from gluonts~=0.11.0->autogluon.timeseries[all]==0.6.1->autogluon) (4.4.0)
    Requirement already satisfied: pydantic~=1.7 in /usr/local/lib/python3.8/dist-packages (from gluonts~=0.11.0->autogluon.timeseries[all]==0.6.1->autogluon) (1.10.2)
    Collecting py4j
      Downloading py4j-0.10.9.7-py2.py3-none-any.whl (200 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m200.5/200.5 kB[0m [31m288.5 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: future in /usr/local/lib/python3.8/dist-packages (from hyperopt<0.2.8,>=0.2.7->autogluon.core[all]==0.6.1->autogluon) (0.16.0)
    Requirement already satisfied: pyrsistent!=0.17.0,!=0.17.1,!=0.17.2,>=0.14.0 in /usr/local/lib/python3.8/dist-packages (from jsonschema<=4.8.0->autogluon.multimodal==0.6.1->autogluon) (0.19.2)
    Requirement already satisfied: attrs>=17.4.0 in /usr/local/lib/python3.8/dist-packages (from jsonschema<=4.8.0->autogluon.multimodal==0.6.1->autogluon) (22.1.0)
    Requirement already satisfied: importlib-resources>=1.4.0 in /usr/local/lib/python3.8/dist-packages (from jsonschema<=4.8.0->autogluon.multimodal==0.6.1->autogluon) (5.10.1)
    Requirement already satisfied: wheel in /usr/local/lib/python3.8/dist-packages (from lightgbm<3.4,>=3.3->autogluon.tabular[all]==0.6.1->autogluon) (0.38.4)
    Requirement already satisfied: regex>=2021.8.3 in /usr/local/lib/python3.8/dist-packages (from nltk<4.0.0,>=3.4.5->autogluon.multimodal==0.6.1->autogluon) (2022.6.2)
    Collecting typish>=1.7.0
      Downloading typish-1.9.3-py3-none-any.whl (45 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m45.1/45.1 kB[0m [31m204.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting antlr4-python3-runtime==4.8
      Downloading antlr4-python3-runtime-4.8.tar.gz (112 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m112.4/112.4 kB[0m [31m289.2 MB/s[0m eta [36m0:00:00[0m
    [?25h  Preparing metadata (setup.py) ... [?25l[?25hdone
    Collecting colorama
      Downloading colorama-0.4.6-py2.py3-none-any.whl (25 kB)
    Collecting rich
      Downloading rich-12.6.0-py3-none-any.whl (237 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m237.5/237.5 kB[0m [31m291.6 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: tabulate in /usr/local/lib/python3.8/dist-packages (from openmim<=0.2.1,>0.1.5->autogluon.multimodal==0.6.1->autogluon) (0.8.10)
    Collecting model-index
      Downloading model_index-0.1.11-py3-none-any.whl (34 kB)
    Requirement already satisfied: python-dateutil>=2.7.3 in /usr/local/lib/python3.8/dist-packages (from pandas!=1.4.0,<1.6,>=1.2.5->autogluon.core[all]==0.6.1->autogluon) (2.8.2)
    Requirement already satisfied: pytz>=2017.3 in /usr/local/lib/python3.8/dist-packages (from pandas!=1.4.0,<1.6,>=1.2.5->autogluon.core[all]==0.6.1->autogluon) (2022.6)
    Requirement already satisfied: Cython!=0.29.18,>=0.29 in /usr/local/lib/python3.8/dist-packages (from pmdarima~=1.8.2->autogluon.timeseries[all]==0.6.1->autogluon) (0.29.32)
    Requirement already satisfied: urllib3 in /usr/local/lib/python3.8/dist-packages (from pmdarima~=1.8.2->autogluon.timeseries[all]==0.6.1->autogluon) (1.24.3)
    Requirement already satisfied: tensorboard>=2.9.1 in /usr/local/lib/python3.8/dist-packages (from pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (2.9.1)
    Collecting pyDeprecate>=0.3.1
      Downloading pyDeprecate-0.3.2-py3-none-any.whl (10 kB)
    Collecting grpcio<=1.43.0,>=1.32.0
      Downloading grpcio-1.43.0-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (4.1 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m4.1/4.1 MB[0m [31m291.0 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: aiosignal in /usr/local/lib/python3.8/dist-packages (from ray[tune]<2.1,>=2.0->autogluon.core[all]==0.6.1->autogluon) (1.3.1)
    Requirement already satisfied: frozenlist in /usr/local/lib/python3.8/dist-packages (from ray[tune]<2.1,>=2.0->autogluon.core[all]==0.6.1->autogluon) (1.3.3)
    Requirement already satisfied: filelock in /usr/local/lib/python3.8/dist-packages (from ray[tune]<2.1,>=2.0->autogluon.core[all]==0.6.1->autogluon) (3.8.2)
    Collecting virtualenv
      Downloading virtualenv-20.17.1-py3-none-any.whl (8.8 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m8.8/8.8 MB[0m [31m217.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: protobuf<4.0.0,>=3.15.3 in /usr/local/lib/python3.8/dist-packages (from ray[tune]<2.1,>=2.0->autogluon.core[all]==0.6.1->autogluon) (3.19.6)
    Collecting tensorboardX>=1.9
      Downloading tensorboardX-2.5.1-py2.py3-none-any.whl (125 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m125.4/125.4 kB[0m [31m255.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: certifi>=2017.4.17 in /usr/local/lib/python3.8/dist-packages (from requests->autogluon.core[all]==0.6.1->autogluon) (2022.12.7)
    Requirement already satisfied: idna<3,>=2.5 in /usr/local/lib/python3.8/dist-packages (from requests->autogluon.core[all]==0.6.1->autogluon) (2.10)
    Requirement already satisfied: chardet<4,>=3.0.2 in /usr/local/lib/python3.8/dist-packages (from requests->autogluon.core[all]==0.6.1->autogluon) (3.0.4)
    Requirement already satisfied: PyWavelets>=1.1.1 in /usr/local/lib/python3.8/dist-packages (from scikit-image<0.20.0,>=0.19.1->autogluon.multimodal==0.6.1->autogluon) (1.4.1)
    Requirement already satisfied: tifffile>=2019.7.26 in /usr/local/lib/python3.8/dist-packages (from scikit-image<0.20.0,>=0.19.1->autogluon.multimodal==0.6.1->autogluon) (2022.10.10)
    Requirement already satisfied: imageio>=2.4.1 in /usr/local/lib/python3.8/dist-packages (from scikit-image<0.20.0,>=0.19.1->autogluon.multimodal==0.6.1->autogluon) (2.9.0)
    Requirement already satisfied: threadpoolctl>=2.0.0 in /usr/local/lib/python3.8/dist-packages (from scikit-learn<1.2,>=1.0.0->autogluon.core[all]==0.6.1->autogluon) (3.1.0)
    Collecting deprecated>=1.2.13
      Downloading Deprecated-1.2.13-py2.py3-none-any.whl (9.6 kB)
    Requirement already satisfied: numba>=0.53 in /usr/local/lib/python3.8/dist-packages (from sktime<0.14,>=0.13.1->autogluon.timeseries[all]==0.6.1->autogluon) (0.56.4)
    Requirement already satisfied: patsy>=0.5.2 in /usr/local/lib/python3.8/dist-packages (from statsmodels~=0.13.0->autogluon.timeseries[all]==0.6.1->autogluon) (0.5.3)
    Collecting tokenizers!=0.11.3,<0.14,>=0.11.1
      Downloading tokenizers-0.13.2-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (7.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m7.6/7.6 MB[0m [31m107.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting jmespath<2.0.0,>=0.7.1
      Downloading jmespath-1.0.1-py3-none-any.whl (20 kB)
    Collecting botocore<1.30.0,>=1.29.39
      Downloading botocore-1.29.39-py3-none-any.whl (10.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m10.3/10.3 MB[0m [31m267.2 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting s3transfer<0.7.0,>=0.6.0
      Downloading s3transfer-0.6.0-py3-none-any.whl (79 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m79.6/79.6 kB[0m [31m276.2 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: pyparsing!=2.0.4,!=2.1.2,!=2.1.6,>=2.0.1 in /usr/local/lib/python3.8/dist-packages (from matplotlib->autogluon.core[all]==0.6.1->autogluon) (3.0.9)
    Requirement already satisfied: cycler>=0.10 in /usr/local/lib/python3.8/dist-packages (from matplotlib->autogluon.core[all]==0.6.1->autogluon) (0.11.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in /usr/local/lib/python3.8/dist-packages (from matplotlib->autogluon.core[all]==0.6.1->autogluon) (1.4.4)
    Collecting urllib3
      Downloading urllib3-1.25.11-py2.py3-none-any.whl (127 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m128.0/128.0 kB[0m [31m315.6 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: aiohttp in /usr/local/lib/python3.8/dist-packages (from datasets>=2.0.0->evaluate<=0.3.0->autogluon.multimodal==0.6.1->autogluon) (3.8.3)
    Requirement already satisfied: pyarrow>=6.0.0 in /usr/local/lib/python3.8/dist-packages (from datasets>=2.0.0->evaluate<=0.3.0->autogluon.multimodal==0.6.1->autogluon) (9.0.0)
    Requirement already satisfied: wrapt<2,>=1.10 in /usr/local/lib/python3.8/dist-packages (from deprecated>=1.2.13->sktime<0.14,>=0.13.1->autogluon.timeseries[all]==0.6.1->autogluon) (1.14.1)
    Requirement already satisfied: zipp>=3.1.0 in /usr/local/lib/python3.8/dist-packages (from importlib-resources>=1.4.0->jsonschema<=4.8.0->autogluon.multimodal==0.6.1->autogluon) (3.11.0)
    Requirement already satisfied: llvmlite<0.40,>=0.39.0dev0 in /usr/local/lib/python3.8/dist-packages (from numba>=0.53->sktime<0.14,>=0.13.1->autogluon.timeseries[all]==0.6.1->autogluon) (0.39.1)
    Requirement already satisfied: importlib-metadata in /usr/local/lib/python3.8/dist-packages (from numba>=0.53->sktime<0.14,>=0.13.1->autogluon.timeseries[all]==0.6.1->autogluon) (5.1.0)
    Requirement already satisfied: locket in /usr/local/lib/python3.8/dist-packages (from partd>=0.3.10->dask<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (1.0.0)
    Requirement already satisfied: spacy-loggers<2.0.0,>=1.0.0 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (1.0.4)
    Requirement already satisfied: typer<0.8.0,>=0.3.0 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (0.7.0)
    Requirement already satisfied: pathy>=0.3.5 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (0.10.1)
    Requirement already satisfied: catalogue<2.1.0,>=2.0.6 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (2.0.8)
    Requirement already satisfied: langcodes<4.0.0,>=3.2.0 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (3.3.0)
    Requirement already satisfied: cymem<2.1.0,>=2.0.2 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (2.0.7)
    Requirement already satisfied: murmurhash<1.1.0,>=0.28.0 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (1.0.9)
    Requirement already satisfied: srsly<3.0.0,>=2.4.3 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (2.4.5)
    Requirement already satisfied: thinc<8.2.0,>=8.1.0 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (8.1.5)
    Requirement already satisfied: preshed<3.1.0,>=3.0.2 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (3.0.8)
    Requirement already satisfied: wasabi<1.1.0,>=0.9.1 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (0.10.1)
    Requirement already satisfied: spacy-legacy<3.1.0,>=3.0.10 in /usr/local/lib/python3.8/dist-packages (from spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (3.0.10)
    Requirement already satisfied: werkzeug>=1.0.1 in /usr/local/lib/python3.8/dist-packages (from tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (1.0.1)
    Requirement already satisfied: markdown>=2.6.8 in /usr/local/lib/python3.8/dist-packages (from tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (3.4.1)
    Requirement already satisfied: google-auth-oauthlib<0.5,>=0.4.1 in /usr/local/lib/python3.8/dist-packages (from tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (0.4.6)
    Requirement already satisfied: google-auth<3,>=1.6.3 in /usr/local/lib/python3.8/dist-packages (from tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (2.15.0)
    Requirement already satisfied: absl-py>=0.4 in /usr/local/lib/python3.8/dist-packages (from tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (1.3.0)
    Requirement already satisfied: tensorboard-plugin-wit>=1.6.0 in /usr/local/lib/python3.8/dist-packages (from tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (1.8.1)
    Requirement already satisfied: tensorboard-data-server<0.7.0,>=0.6.0 in /usr/local/lib/python3.8/dist-packages (from tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (0.6.1)
    Requirement already satisfied: heapdict in /usr/local/lib/python3.8/dist-packages (from zict>=0.1.3->distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (1.0.1)
    Requirement already satisfied: MarkupSafe>=0.23 in /usr/local/lib/python3.8/dist-packages (from jinja2->distributed<=2021.11.2,>=2021.09.1->autogluon.core[all]==0.6.1->autogluon) (2.0.1)
    Collecting ordered-set
      Downloading ordered_set-4.1.0-py3-none-any.whl (7.6 kB)
    Requirement already satisfied: tenacity>=6.2.0 in /usr/local/lib/python3.8/dist-packages (from plotly->catboost<1.2,>=1.0->autogluon.tabular[all]==0.6.1->autogluon) (8.1.0)
    Requirement already satisfied: pygments<3.0.0,>=2.6.0 in /usr/local/lib/python3.8/dist-packages (from rich->openmim<=0.2.1,>0.1.5->autogluon.multimodal==0.6.1->autogluon) (2.6.1)
    Collecting commonmark<0.10.0,>=0.9.0
      Downloading commonmark-0.9.1-py2.py3-none-any.whl (51 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m51.1/51.1 kB[0m [31m6.2 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting distlib<1,>=0.3.6
      Downloading distlib-0.3.6-py2.py3-none-any.whl (468 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m468.5/468.5 kB[0m [31m304.5 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: platformdirs<3,>=2.4 in /usr/local/lib/python3.8/dist-packages (from virtualenv->ray[tune]<2.1,>=2.0->autogluon.core[all]==0.6.1->autogluon) (2.6.0)
    Requirement already satisfied: multidict<7.0,>=4.5 in /usr/local/lib/python3.8/dist-packages (from aiohttp->datasets>=2.0.0->evaluate<=0.3.0->autogluon.multimodal==0.6.1->autogluon) (6.0.3)
    Requirement already satisfied: yarl<2.0,>=1.0 in /usr/local/lib/python3.8/dist-packages (from aiohttp->datasets>=2.0.0->evaluate<=0.3.0->autogluon.multimodal==0.6.1->autogluon) (1.8.2)
    Requirement already satisfied: async-timeout<5.0,>=4.0.0a3 in /usr/local/lib/python3.8/dist-packages (from aiohttp->datasets>=2.0.0->evaluate<=0.3.0->autogluon.multimodal==0.6.1->autogluon) (4.0.2)
    Requirement already satisfied: charset-normalizer<3.0,>=2.0 in /usr/local/lib/python3.8/dist-packages (from aiohttp->datasets>=2.0.0->evaluate<=0.3.0->autogluon.multimodal==0.6.1->autogluon) (2.1.1)
    Requirement already satisfied: pyasn1-modules>=0.2.1 in /usr/local/lib/python3.8/dist-packages (from google-auth<3,>=1.6.3->tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (0.2.8)
    Requirement already satisfied: cachetools<6.0,>=2.0.0 in /usr/local/lib/python3.8/dist-packages (from google-auth<3,>=1.6.3->tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (5.2.0)
    Requirement already satisfied: rsa<5,>=3.1.4 in /usr/local/lib/python3.8/dist-packages (from google-auth<3,>=1.6.3->tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (4.9)
    Requirement already satisfied: requests-oauthlib>=0.7.0 in /usr/local/lib/python3.8/dist-packages (from google-auth-oauthlib<0.5,>=0.4.1->tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (1.3.1)
    Requirement already satisfied: confection<1.0.0,>=0.0.1 in /usr/local/lib/python3.8/dist-packages (from thinc<8.2.0,>=8.1.0->spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (0.0.3)
    Requirement already satisfied: blis<0.8.0,>=0.7.8 in /usr/local/lib/python3.8/dist-packages (from thinc<8.2.0,>=8.1.0->spacy<4->fastai<2.8,>=2.3.1->autogluon.tabular[all]==0.6.1->autogluon) (0.7.9)
    Requirement already satisfied: pyasn1<0.5.0,>=0.4.6 in /usr/local/lib/python3.8/dist-packages (from pyasn1-modules>=0.2.1->google-auth<3,>=1.6.3->tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (0.4.8)
    Requirement already satisfied: oauthlib>=3.0.0 in /usr/local/lib/python3.8/dist-packages (from requests-oauthlib>=0.7.0->google-auth-oauthlib<0.5,>=0.4.1->tensorboard>=2.9.1->pytorch-lightning<1.8.0,>=1.7.4->autogluon.multimodal==0.6.1->autogluon) (3.2.2)
    Building wheels for collected packages: fairscale, antlr4-python3-runtime, seqeval
      Building wheel for fairscale (pyproject.toml) ... [?25l[?25hdone
      Created wheel for fairscale: filename=fairscale-0.4.6-py3-none-any.whl size=307224 sha256=845c1c0a1d70ba218c71717eddb0ed4493d94c720d3fca8acf5fe8aa39a45b84
      Stored in directory: /tmp/pip-ephem-wheel-cache-5nccikeb/wheels/60/e8/f1/4f2cc869823c35e834c6cee0552a0605c2bdc89f7da81f1a1d
      Building wheel for antlr4-python3-runtime (setup.py) ... [?25l[?25hdone
      Created wheel for antlr4-python3-runtime: filename=antlr4_python3_runtime-4.8-py3-none-any.whl size=141211 sha256=43bb05a5a4582c7ca4508713bf7935b173d4743a6a2df4b701596f70618eb28b
      Stored in directory: /tmp/pip-ephem-wheel-cache-5nccikeb/wheels/34/d7/fe/a833ceccaee881c6f8cd49985ee4285bf94c5cf2c66ea5db68
      Building wheel for seqeval (setup.py) ... [?25l[?25hdone
      Created wheel for seqeval: filename=seqeval-1.2.2-py3-none-any.whl size=16164 sha256=d635b8ee763025a2c7629bc82b1c98e4bb62da9cf567929d41da069cace6e01a
      Stored in directory: /tmp/pip-ephem-wheel-cache-5nccikeb/wheels/e3/30/9b/6b670dac34775f2b7cc4e9b172202e81fbb4f9cdb103c1ca66
    Successfully built fairscale antlr4-python3-runtime seqeval
    Installing collected packages: typish, tokenizers, sentencepiece, py4j, distlib, commonmark, antlr4-python3-runtime, yacs, xxhash, virtualenv, urllib3, torch, tensorboardX, smart-open, rich, pyDeprecate, psutil, portalocker, Pillow, ordered-set, omegaconf, nptyping, multiprocess, jmespath, grpcio, deprecated, colorama, autocfg, xgboost, torchmetrics, hyperopt, fairscale, dask, botocore, accelerate, torchvision, torchtext, statsmodels, seqeval, scikit-image, s3transfer, responses, ray, nlpaug, model-index, lightgbm, huggingface-hub, gluonts, gluoncv, distributed, catboost, transformers, timm, sktime, pytorch-metric-learning, pmdarima, openmim, datasets, boto3, albumentations, tbats, evaluate, autogluon.common, pytorch-lightning, autogluon.features, autogluon.core, autogluon.tabular, autogluon.multimodal, autogluon.vision, autogluon.timeseries, autogluon.text, autogluon
      Attempting uninstall: urllib3
        Found existing installation: urllib3 1.24.3
        Uninstalling urllib3-1.24.3:
          Successfully uninstalled urllib3-1.24.3
      Attempting uninstall: torch
        Found existing installation: torch 1.13.0+cu116
        Uninstalling torch-1.13.0+cu116:
          Successfully uninstalled torch-1.13.0+cu116
      Attempting uninstall: smart-open
        Found existing installation: smart-open 6.3.0
        Uninstalling smart-open-6.3.0:
          Successfully uninstalled smart-open-6.3.0
      Attempting uninstall: psutil
        Found existing installation: psutil 5.4.8
        Uninstalling psutil-5.4.8:
          Successfully uninstalled psutil-5.4.8
      Attempting uninstall: Pillow
        Found existing installation: Pillow 7.1.2
        Uninstalling Pillow-7.1.2:
          Successfully uninstalled Pillow-7.1.2
      Attempting uninstall: grpcio
        Found existing installation: grpcio 1.51.1
        Uninstalling grpcio-1.51.1:
          Successfully uninstalled grpcio-1.51.1
      Attempting uninstall: xgboost
        Found existing installation: xgboost 0.90
        Uninstalling xgboost-0.90:
          Successfully uninstalled xgboost-0.90
      Attempting uninstall: hyperopt
        Found existing installation: hyperopt 0.1.2
        Uninstalling hyperopt-0.1.2:
          Successfully uninstalled hyperopt-0.1.2
      Attempting uninstall: dask
        Found existing installation: dask 2022.2.1
        Uninstalling dask-2022.2.1:
          Successfully uninstalled dask-2022.2.1
      Attempting uninstall: torchvision
        Found existing installation: torchvision 0.14.0+cu116
        Uninstalling torchvision-0.14.0+cu116:
          Successfully uninstalled torchvision-0.14.0+cu116
      Attempting uninstall: torchtext
        Found existing installation: torchtext 0.14.0
        Uninstalling torchtext-0.14.0:
          Successfully uninstalled torchtext-0.14.0
      Attempting uninstall: statsmodels
        Found existing installation: statsmodels 0.12.2
        Uninstalling statsmodels-0.12.2:
          Successfully uninstalled statsmodels-0.12.2
      Attempting uninstall: scikit-image
        Found existing installation: scikit-image 0.18.3
        Uninstalling scikit-image-0.18.3:
          Successfully uninstalled scikit-image-0.18.3
      Attempting uninstall: lightgbm
        Found existing installation: lightgbm 2.2.3
        Uninstalling lightgbm-2.2.3:
          Successfully uninstalled lightgbm-2.2.3
      Attempting uninstall: distributed
        Found existing installation: distributed 2022.2.1
        Uninstalling distributed-2022.2.1:
          Successfully uninstalled distributed-2022.2.1
      Attempting uninstall: albumentations
        Found existing installation: albumentations 1.2.1
        Uninstalling albumentations-1.2.1:
          Successfully uninstalled albumentations-1.2.1
    [31mERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    torchaudio 0.13.0+cu116 requires torch==1.13.0, but you have torch 1.12.1 which is incompatible.
    panel 0.12.1 requires bokeh<2.4.0,>=2.3.0, but you have bokeh 2.0.1 which is incompatible.
    grpcio-status 1.48.2 requires grpcio>=1.48.2, but you have grpcio 1.43.0 which is incompatible.
    google-cloud-bigquery 3.3.6 requires grpcio<2.0dev,>=1.47.0, but you have grpcio 1.43.0 which is incompatible.[0m[31m
    [0mSuccessfully installed Pillow-9.3.0 accelerate-0.13.2 albumentations-1.1.0 antlr4-python3-runtime-4.8 autocfg-0.0.8 autogluon-0.6.1 autogluon.common-0.6.1 autogluon.core-0.6.1 autogluon.features-0.6.1 autogluon.multimodal-0.6.1 autogluon.tabular-0.6.1 autogluon.text-0.6.1 autogluon.timeseries-0.6.1 autogluon.vision-0.6.1 boto3-1.26.39 botocore-1.29.39 catboost-1.1.1 colorama-0.4.6 commonmark-0.9.1 dask-2021.11.2 datasets-2.8.0 deprecated-1.2.13 distlib-0.3.6 distributed-2021.11.2 evaluate-0.3.0 fairscale-0.4.6 gluoncv-0.10.5.post0 gluonts-0.11.6 grpcio-1.43.0 huggingface-hub-0.11.1 hyperopt-0.2.7 jmespath-1.0.1 lightgbm-3.3.3 model-index-0.1.11 multiprocess-0.70.14 nlpaug-1.1.10 nptyping-1.4.4 omegaconf-2.1.2 openmim-0.2.1 ordered-set-4.1.0 pmdarima-1.8.5 portalocker-2.6.0 psutil-5.8.0 py4j-0.10.9.7 pyDeprecate-0.3.2 pytorch-lightning-1.7.7 pytorch-metric-learning-1.3.2 ray-2.0.1 responses-0.18.0 rich-12.6.0 s3transfer-0.6.0 scikit-image-0.19.3 sentencepiece-0.1.97 seqeval-1.2.2 sktime-0.13.4 smart-open-5.2.1 statsmodels-0.13.5 tbats-1.1.2 tensorboardX-2.5.1 timm-0.6.12 tokenizers-0.13.2 torch-1.12.1 torchmetrics-0.8.2 torchtext-0.13.1 torchvision-0.13.1 transformers-4.23.1 typish-1.9.3 urllib3-1.25.11 virtualenv-20.17.1 xgboost-1.7.2 xxhash-3.2.0 yacs-0.1.8
    [33mWARNING: Running pip as the 'root' user can result in broken permissions and conflicting behaviour with the system package manager. It is recommended to use a virtual environment instead: https://pip.pypa.io/warnings/venv[0m[33m
    [0m

### Setup Kaggle API Key


```python
# create the .kaggle directory and an empty kaggle.json file
!mkdir -p /root/.kaggle
!touch /root/.kaggle/kaggle.json
!chmod 600 /root/.kaggle/kaggle.json
```


```python
# Fill in your user name and key from creating the kaggle account and API token file
import json
kaggle_username = "rethinaduraisj"
kaggle_key = "f533c759f6b84b373c7bc03930fa4eb3"

# Save API token the kaggle.json file
with open("/root/.kaggle/kaggle.json", "w") as f:
    f.write(json.dumps({"username": kaggle_username, "key": kaggle_key}))
```

### Download and explore dataset

### Go to the bike sharing demand competition and agree to the terms
![kaggle6.png](attachment:kaggle6.png)


```python
# Download the dataset, it will be in a .zip file so you'll need to unzip it as well.
!kaggle competitions download -c bike-sharing-demand
# If you already downloaded it you can use the -o command to overwrite the file
!unzip -o bike-sharing-demand.zip
```

    Downloading bike-sharing-demand.zip to /content
    100% 189k/189k [00:00<00:00, 424kB/s]
    100% 189k/189k [00:00<00:00, 423kB/s]
    Archive:  bike-sharing-demand.zip
      inflating: sampleSubmission.csv    
      inflating: test.csv                
      inflating: train.csv               
    


```python
import pandas as pd
from autogluon.tabular import TabularPredictor
```


```python
# Create the train dataset in pandas by reading the csv
# Set the parsing of the datetime column so you can use some of the `dt` features in pandas later
train = pd.read_csv("train.csv")
```


```python
train.head()
```





  <div id="df-7d3fc2e6-1122-4798-b731-6c891c2319aa">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-7d3fc2e6-1122-4798-b731-6c891c2319aa')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-7d3fc2e6-1122-4798-b731-6c891c2319aa button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-7d3fc2e6-1122-4798-b731-6c891c2319aa');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
train = train.drop('casual', axis=1)
```


```python
train = train.drop('registered', axis=1)
```


```python
train["datetime"]=pd.to_datetime(train["datetime"])
```


```python
# Simple output of the train dataset to view some of the min/max/varition of the dataset features.
train.describe()
```





  <div id="df-0ef99d6e-3e4c-458f-85e9-facfc985bc9f">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.00000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
      <td>10886.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2.506614</td>
      <td>0.028569</td>
      <td>0.680875</td>
      <td>1.418427</td>
      <td>20.23086</td>
      <td>23.655084</td>
      <td>61.886460</td>
      <td>12.799395</td>
      <td>191.574132</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.116174</td>
      <td>0.166599</td>
      <td>0.466159</td>
      <td>0.633839</td>
      <td>7.79159</td>
      <td>8.474601</td>
      <td>19.245033</td>
      <td>8.164537</td>
      <td>181.144454</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.82000</td>
      <td>0.760000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>13.94000</td>
      <td>16.665000</td>
      <td>47.000000</td>
      <td>7.001500</td>
      <td>42.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>20.50000</td>
      <td>24.240000</td>
      <td>62.000000</td>
      <td>12.998000</td>
      <td>145.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>26.24000</td>
      <td>31.060000</td>
      <td>77.000000</td>
      <td>16.997900</td>
      <td>284.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>4.000000</td>
      <td>41.00000</td>
      <td>45.455000</td>
      <td>100.000000</td>
      <td>56.996900</td>
      <td>977.000000</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-0ef99d6e-3e4c-458f-85e9-facfc985bc9f')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-0ef99d6e-3e4c-458f-85e9-facfc985bc9f button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-0ef99d6e-3e4c-458f-85e9-facfc985bc9f');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
train.head()
```





  <div id="df-0f445035-0334-4ee9-a565-c3c751507594">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0</td>
      <td>16</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>32</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-0f445035-0334-4ee9-a565-c3c751507594')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-0f445035-0334-4ee9-a565-c3c751507594 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-0f445035-0334-4ee9-a565-c3c751507594');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
# Create the test pandas dataframe in pandas by reading the csv, remember to parse the datetime!
test = pd.read_csv("test.csv")
test["datetime"]=pd.to_datetime(test["datetime"])
test.head()
```





  <div id="df-c6014a09-1b38-4fec-aea5-4c634e9bab65">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-20 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>11.365</td>
      <td>56</td>
      <td>26.0027</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-20 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>13.635</td>
      <td>56</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-20 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>13.635</td>
      <td>56</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-20 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>12.880</td>
      <td>56</td>
      <td>11.0014</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-20 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>12.880</td>
      <td>56</td>
      <td>11.0014</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-c6014a09-1b38-4fec-aea5-4c634e9bab65')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-c6014a09-1b38-4fec-aea5-4c634e9bab65 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-c6014a09-1b38-4fec-aea5-4c634e9bab65');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
# Same thing as train and test dataset
submission = pd.read_csv("sampleSubmission.csv")
submission.head()
```





  <div id="df-5cfba45b-a715-4fa7-8ee0-065d207c064c">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-20 00:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-20 01:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-20 02:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-20 03:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-20 04:00:00</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-5cfba45b-a715-4fa7-8ee0-065d207c064c')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-5cfba45b-a715-4fa7-8ee0-065d207c064c button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-5cfba45b-a715-4fa7-8ee0-065d207c064c');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>




## Step 3: Train a model using AutoGluon’s Tabular Prediction

Requirements:
* We are prediting `count`, so it is the label we are setting.
* Ignore `casual` and `registered` columns as they are also not present in the test dataset. 
* Use the `root_mean_squared_error` as the metric to use for evaluation.
* Set a time limit of 10 minutes (600 seconds).
* Use the preset `best_quality` to focus on creating the best model.


```python
predictor = TabularPredictor(label="count", problem_type="regression", eval_metric="root_mean_squared_error").fit(
    train_data=train, time_limit=600, presets="best_quality"
)
```

    No path specified. Models will be saved in: "AutogluonModels/ag-20221228_035727/"
    Presets specified: ['best_quality']
    Stack configuration (auto_stack=True): num_stack_levels=1, num_bag_folds=8, num_bag_sets=20
    Beginning AutoGluon training ... Time limit = 600s
    AutoGluon will save models to "AutogluonModels/ag-20221228_035727/"
    AutoGluon Version:  0.6.1
    Python Version:     3.8.16
    Operating System:   Linux
    Platform Machine:   x86_64
    Platform Version:   #1 SMP Fri Aug 26 08:44:51 UTC 2022
    Train Data Rows:    10886
    Train Data Columns: 9
    Label Column: count
    Preprocessing data ...
    Using Feature Generators to preprocess the data ...
    Fitting AutoMLPipelineFeatureGenerator...
    	Available Memory:                    12210.18 MB
    	Train Data (Original)  Memory Usage: 0.78 MB (0.0% of available memory)
    	Inferring data type of each feature based on column values. Set feature_metadata_in to manually specify special dtypes of the features.
    	Stage 1 Generators:
    		Fitting AsTypeFeatureGenerator...
    			Note: Converting 2 features to boolean dtype as they only contain 2 unique values.
    	Stage 2 Generators:
    		Fitting FillNaFeatureGenerator...
    	Stage 3 Generators:
    		Fitting IdentityFeatureGenerator...
    		Fitting DatetimeFeatureGenerator...
    /usr/local/lib/python3.8/dist-packages/autogluon/features/generators/datetime.py:59: FutureWarning: casting datetime64[ns, UTC] values to int64 with .astype(...) is deprecated and will raise in a future version. Use .view(...) instead.
      good_rows = series[~series.isin(bad_rows)].astype(np.int64)
    	Stage 4 Generators:
    		Fitting DropUniqueFeatureGenerator...
    	Types of features in original data (raw dtype, special dtypes):
    		('datetime', []) : 1 | ['datetime']
    		('float', [])    : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])      : 5 | ['season', 'holiday', 'workingday', 'weather', 'humidity']
    	Types of features in processed data (raw dtype, special dtypes):
    		('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])                  : 3 | ['season', 'weather', 'humidity']
    		('int', ['bool'])            : 2 | ['holiday', 'workingday']
    		('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    	0.5s = Fit runtime
    	9 features in original data used to generate 13 features in processed data.
    	Train Data (Processed) Memory Usage: 0.98 MB (0.0% of available memory)
    Data preprocessing and feature engineering runtime = 0.52s ...
    AutoGluon will gauge predictive performance using evaluation metric: 'root_mean_squared_error'
    	This metric's sign has been flipped to adhere to being higher_is_better. The metric score can be multiplied by -1 to get the metric value.
    	To change this, specify the eval_metric parameter of Predictor()
    AutoGluon will fit 2 stack levels (L1 to L2) ...
    Fitting 11 L1 models ...
    Fitting model: KNeighborsUnif_BAG_L1 ... Training model for up to 399.55s of the 599.46s of remaining time.
    	-101.5462	 = Validation score   (-root_mean_squared_error)
    	0.04s	 = Training   runtime
    	0.08s	 = Validation runtime
    Fitting model: KNeighborsDist_BAG_L1 ... Training model for up to 399.31s of the 599.22s of remaining time.
    	-84.1251	 = Validation score   (-root_mean_squared_error)
    	0.03s	 = Training   runtime
    	0.03s	 = Validation runtime
    Fitting model: LightGBMXT_BAG_L1 ... Training model for up to 398.55s of the 598.46s of remaining time.
    


    ---------------------------------------------------------------------------

    KeyboardInterrupt                         Traceback (most recent call last)

    <ipython-input-15-744903cbb934> in <module>
    ----> 1 predictor = TabularPredictor(label="count", problem_type="regression", eval_metric="root_mean_squared_error").fit(
          2     train_data=train, time_limit=600, presets="best_quality"
          3 )
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/utils/decorators.py in _call(*args, **kwargs)
         28         def _call(*args, **kwargs):
         29             gargs, gkwargs = g(*other_args, *args, **kwargs)
    ---> 30             return f(*gargs, **gkwargs)
         31         return _call
         32     return _unpack_inner
    

    /usr/local/lib/python3.8/dist-packages/autogluon/tabular/predictor/predictor.py in fit(self, train_data, tuning_data, time_limit, presets, hyperparameters, feature_metadata, infer_limit, infer_limit_batch_size, fit_weighted_ensemble, num_cpus, num_gpus, **kwargs)
        858             aux_kwargs['fit_weighted_ensemble'] = False
        859         self.save(silent=True)  # Save predictor to disk to enable prediction and training after interrupt
    --> 860         self._learner.fit(X=train_data, X_val=tuning_data, X_unlabeled=unlabeled_data,
        861                           holdout_frac=holdout_frac, num_bag_folds=num_bag_folds, num_bag_sets=num_bag_sets,
        862                           num_stack_levels=num_stack_levels,
    

    /usr/local/lib/python3.8/dist-packages/autogluon/tabular/learner/abstract_learner.py in fit(self, X, X_val, **kwargs)
        123             raise AssertionError('Learner is already fit.')
        124         self._validate_fit_input(X=X, X_val=X_val, **kwargs)
    --> 125         return self._fit(X=X, X_val=X_val, **kwargs)
        126 
        127     def _fit(self, X: DataFrame, X_val: DataFrame = None, scheduler_options=None, hyperparameter_tune=False,
    

    /usr/local/lib/python3.8/dist-packages/autogluon/tabular/learner/default_learner.py in _fit(self, X, X_val, X_unlabeled, holdout_frac, num_bag_folds, num_bag_sets, time_limit, infer_limit, infer_limit_batch_size, verbosity, **trainer_fit_kwargs)
        116 
        117         self.save()
    --> 118         trainer.fit(
        119             X=X,
        120             y=y,
    

    /usr/local/lib/python3.8/dist-packages/autogluon/tabular/trainer/auto_trainer.py in fit(self, X, y, hyperparameters, X_val, y_val, X_unlabeled, holdout_frac, num_stack_levels, core_kwargs, aux_kwargs, time_limit, infer_limit, infer_limit_batch_size, use_bag_holdout, groups, **kwargs)
         86                                      'Bagging/Stacking with a held-out validation set (blend stacking) is not yet supported.')
         87 
    ---> 88         self._train_multi_and_ensemble(X=X,
         89                                        y=y,
         90                                        X_val=X_val,
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in _train_multi_and_ensemble(self, X, y, X_val, y_val, hyperparameters, X_unlabeled, num_stack_levels, time_limit, groups, **kwargs)
       1962             self._num_rows_train += len(X_val)
       1963         self._num_cols_train = len(list(X.columns))
    -> 1964         model_names_fit = self.train_multi_levels(X, y, hyperparameters=hyperparameters, X_val=X_val, y_val=y_val,
       1965                                                   X_unlabeled=X_unlabeled, level_start=1, level_end=num_stack_levels+1, time_limit=time_limit, **kwargs)
       1966         if len(self.get_model_names()) == 0:
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in train_multi_levels(self, X, y, hyperparameters, X_val, y_val, X_unlabeled, base_model_names, core_kwargs, aux_kwargs, level_start, level_end, time_limit, name_suffix, relative_stack, level_time_modifier, infer_limit, infer_limit_batch_size)
        298                 core_kwargs_level['time_limit'] = core_kwargs_level.get('time_limit', time_limit_core)
        299                 aux_kwargs_level['time_limit'] = aux_kwargs_level.get('time_limit', time_limit_aux)
    --> 300             base_model_names, aux_models = self.stack_new_level(
        301                 X=X, y=y, X_val=X_val, y_val=y_val, X_unlabeled=X_unlabeled,
        302                 models=hyperparameters, level=level, base_model_names=base_model_names,
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in stack_new_level(self, X, y, models, X_val, y_val, X_unlabeled, level, base_model_names, core_kwargs, aux_kwargs, name_suffix, infer_limit, infer_limit_batch_size)
        415             core_kwargs['name_suffix'] = core_kwargs.get('name_suffix', '') + name_suffix
        416             aux_kwargs['name_suffix'] = aux_kwargs.get('name_suffix', '') + name_suffix
    --> 417         core_models = self.stack_new_level_core(X=X, y=y, X_val=X_val, y_val=y_val, X_unlabeled=X_unlabeled, models=models,
        418                                                 level=level, infer_limit=infer_limit, infer_limit_batch_size=infer_limit_batch_size, base_model_names=base_model_names, **core_kwargs)
        419 
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in stack_new_level_core(self, X, y, models, X_val, y_val, X_unlabeled, level, base_model_names, stack_name, ag_args, ag_args_fit, ag_args_ensemble, excluded_model_types, ensemble_type, name_suffix, get_models_func, refit_full, infer_limit, infer_limit_batch_size, **kwargs)
        506 
        507         # FIXME: TODO: v0.1 X_unlabeled isn't cached so it won't be available during refit_full or fit_extra.
    --> 508         return self._train_multi(X=X_init, y=y, X_val=X_val, y_val=y_val, X_unlabeled=X_unlabeled,
        509                                  models=models, level=level, stack_name=stack_name, compute_score=compute_score, fit_kwargs=fit_kwargs, **kwargs)
        510 
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in _train_multi(self, X, y, models, hyperparameter_tune_kwargs, feature_prune_kwargs, k_fold, n_repeats, n_repeat_start, time_limit, **kwargs)
       1932         if n_repeat_start == 0:
       1933             time_start = time.time()
    -> 1934             model_names_trained = self._train_multi_initial(X=X, y=y, models=models, k_fold=k_fold, n_repeats=n_repeats_initial, hyperparameter_tune_kwargs=hyperparameter_tune_kwargs,
       1935                                                             feature_prune_kwargs=feature_prune_kwargs, time_limit=time_limit, **kwargs)
       1936             n_repeat_start = n_repeats_initial
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in _train_multi_initial(self, X, y, models, k_fold, n_repeats, hyperparameter_tune_kwargs, time_limit, feature_prune_kwargs, **kwargs)
       1828         else:
       1829             time_ratio = hpo_time_ratio if hpo_enabled else 1
    -> 1830             models = self._train_multi_fold(models=models, hyperparameter_tune_kwargs=hyperparameter_tune_kwargs, k_fold_start=0,
       1831                                             k_fold_end=k_fold, n_repeats=n_repeats, n_repeat_start=0, time_limit=time_limit,
       1832                                             time_split=time_split, time_ratio=time_ratio, **fit_args)
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in _train_multi_fold(self, X, y, models, time_limit, time_split, time_ratio, hyperparameter_tune_kwargs, **kwargs)
       1903                     time_start_model = time.time()
       1904                     time_left = time_limit - (time_start_model - time_start)
    -> 1905             model_name_trained_lst = self._train_single_full(X, y, model, time_limit=time_left, hyperparameter_tune_kwargs=hyperparameter_tune_kwargs_model, **kwargs)
       1906 
       1907             if self.low_memory:
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in _train_single_full(self, X, y, model, X_unlabeled, X_val, y_val, X_pseudo, y_pseudo, feature_prune, hyperparameter_tune_kwargs, stack_name, k_fold, k_fold_start, k_fold_end, n_repeats, n_repeat_start, level, time_limit, fit_kwargs, compute_score, total_resources, **kwargs)
       1721                 bagged_model_fit_kwargs = self._get_bagged_model_fit_kwargs(k_fold=k_fold, k_fold_start=k_fold_start, k_fold_end=k_fold_end, n_repeats=n_repeats, n_repeat_start=n_repeat_start)
       1722                 model_fit_kwargs.update(bagged_model_fit_kwargs)
    -> 1723             model_names_trained = self._train_and_save(
       1724                 X=X,
       1725                 y=y,
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in _train_and_save(self, X, y, model, X_val, y_val, stack_name, level, compute_score, total_resources, **model_fit_kwargs)
       1420                 model = self._train_single(X_w_pseudo, y_w_pseudo, model, X_val, y_val, **model_fit_kwargs)
       1421             else:
    -> 1422                 model = self._train_single(X, y, model, X_val, y_val, total_resources=total_resources, **model_fit_kwargs)
       1423 
       1424             fit_end_time = time.time()
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/trainer/abstract_trainer.py in _train_single(self, X, y, model, X_val, y_val, total_resources, **model_fit_kwargs)
       1365         Returns trained model object.
       1366         """
    -> 1367         model = model.fit(X=X, y=y, X_val=X_val, y_val=y_val, total_resources=total_resources, **model_fit_kwargs)
       1368         return model
       1369 
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/models/abstract/abstract_model.py in fit(self, **kwargs)
        694         self.validate_fit_resources(**kwargs)
        695         self._validate_fit_memory_usage(**kwargs)
    --> 696         out = self._fit(**kwargs)
        697         if out is None:
        698             out = self
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/models/ensemble/stacker_ensemble_model.py in _fit(self, X, y, compute_base_preds, time_limit, **kwargs)
        152         if time_limit is not None:
        153             time_limit = time_limit - (time.time() - start_time)
    --> 154         return super()._fit(X=X, y=y, time_limit=time_limit, **kwargs)
        155 
        156     def set_contexts(self, path_context):
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/models/ensemble/bagged_ensemble_model.py in _fit(self, X, y, X_val, y_val, X_pseudo, y_pseudo, k_fold, k_fold_start, k_fold_end, n_repeats, n_repeat_start, groups, **kwargs)
        234                     # Reserve time for final refit model
        235                     kwargs['time_limit'] = kwargs['time_limit'] * folds_to_fit / (folds_to_fit + 1.2)
    --> 236             self._fit_folds(X=X, y=y, model_base=model_base, X_pseudo=X_pseudo, y_pseudo=y_pseudo,
        237                             k_fold=k_fold, k_fold_start=k_fold_start, k_fold_end=k_fold_end,
        238                             n_repeats=n_repeats, n_repeat_start=n_repeat_start, save_folds=save_bag_folds, groups=groups, **kwargs)
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/models/ensemble/bagged_ensemble_model.py in _fit_folds(self, X, y, model_base, X_pseudo, y_pseudo, k_fold, k_fold_start, k_fold_end, n_repeats, n_repeat_start, time_limit, sample_weight, save_folds, groups, num_cpus, num_gpus, **kwargs)
        437                 fold_fitting_strategy = self.params.get('fold_fitting_strategy_cpu', fold_fitting_strategy)
        438         if fold_fitting_strategy == 'auto':
    --> 439             fold_fitting_strategy = self._get_default_fold_fitting_strategy()
        440         num_folds_parallel = self.params.get('num_folds_parallel', 'auto')
        441         disable_parallel_fitting = self.params.get('_disable_parallel_fitting', False)
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/models/ensemble/bagged_ensemble_model.py in _get_default_fold_fitting_strategy(self)
        402         else:
        403             try:
    --> 404                 try_import_ray()
        405             except Exception as e:
        406                 warning_msg = f'Will use sequential fold fitting strategy because import of ray failed. Reason: {str(e)}'
    

    /usr/local/lib/python3.8/dist-packages/autogluon/core/utils/try_import.py in try_import_ray()
         65     ray_max_version = ray_max_version_os_map.get(current_os, RAY_MAX_VERSION)
         66     try:
    ---> 67         import ray
         68         from distutils.version import LooseVersion
         69 
    

    /usr/local/lib/python3.8/dist-packages/ray/__init__.py in <module>
        114 __version__ = "2.0.1"
        115 
    --> 116 import ray._raylet  # noqa: E402
        117 
        118 from ray._raylet import (  # noqa: E402
    

    python/ray/_raylet.pyx in init ray._raylet()
    

    /usr/local/lib/python3.8/dist-packages/ray/exceptions.py in <module>
         15     RayException,
         16 )
    ---> 17 from ray.util.annotations import DeveloperAPI, PublicAPI
         18 
         19 import setproctitle
    

    /usr/local/lib/python3.8/dist-packages/ray/util/__init__.py in <module>
          5 from ray._private.services import get_node_ip_address
          6 from ray.util import iter
    ----> 7 from ray.util import rpdb as pdb
          8 from ray.util.actor_pool import ActorPool
          9 from ray.util.annotations import PublicAPI
    

    /usr/lib/python3.8/importlib/_bootstrap.py in _find_and_load(name, import_)
    

    /usr/lib/python3.8/importlib/_bootstrap.py in _find_and_load_unlocked(name, import_)
    

    /usr/lib/python3.8/importlib/_bootstrap.py in _find_spec(name, path, target)
    

    /usr/lib/python3.8/importlib/_bootstrap_external.py in find_spec(cls, fullname, path, target)
    

    /usr/lib/python3.8/importlib/_bootstrap_external.py in _get_spec(cls, fullname, path, target)
    

    /usr/lib/python3.8/importlib/_bootstrap_external.py in find_spec(self, fullname, target)
    

    KeyboardInterrupt: 


### Review AutoGluon's training run with ranking of models that did the best.


```python
predictor.fit_summary()
```

    *** Summary of fit() ***
    Estimated performance of each model:
                         model   score_val  pred_time_val    fit_time  pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  fit_order
    0      WeightedEnsemble_L3  -53.109959      18.317078  558.420917                0.001603           0.553841            3       True         14
    1   RandomForestMSE_BAG_L2  -53.431890      13.282965  412.461576                0.764616          29.314505            2       True         12
    2          LightGBM_BAG_L2  -55.035680      13.016691  412.660578                0.498343          29.513508            2       True         11
    3          CatBoost_BAG_L2  -56.003877      12.687824  427.685627                0.169475          44.538556            2       True         13
    4        LightGBMXT_BAG_L2  -60.370184      16.883042  454.500507                4.364693          71.353436            2       True         10
    5    KNeighborsDist_BAG_L1  -84.125061       0.047710    0.045261                0.047710           0.045261            1       True          2
    6      WeightedEnsemble_L2  -84.125061       0.049071    0.916815                0.001361           0.871554            2       True          9
    7    KNeighborsUnif_BAG_L1 -101.546199       0.045886    0.043096                0.045886           0.043096            1       True          1
    8   RandomForestMSE_BAG_L1 -116.544294       0.642890   12.323581                0.642890          12.323581            1       True          5
    9     ExtraTreesMSE_BAG_L1 -124.588053       0.637248    6.103706                0.637248           6.103706            1       True          7
    10         CatBoost_BAG_L1 -130.585937       0.142637  199.241410                0.142637         199.241410            1       True          6
    11         LightGBM_BAG_L1 -131.054162       1.224466   33.795891                1.224466          33.795891            1       True          4
    12       LightGBMXT_BAG_L1 -131.460909       9.212330   71.632729                9.212330          71.632729            1       True          3
    13  NeuralNetFastAI_BAG_L1 -140.478323       0.565181   59.961397                0.565181          59.961397            1       True          8
    Number of models trained: 14
    Types of models trained:
    {'StackerEnsembleModel_NNFastAiTabular', 'StackerEnsembleModel_RF', 'WeightedEnsembleModel', 'StackerEnsembleModel_KNN', 'StackerEnsembleModel_XT', 'StackerEnsembleModel_LGB', 'StackerEnsembleModel_CatBoost'}
    Bagging used: True  (with 8 folds)
    Multi-layer stack-ensembling used: True  (with 3 levels)
    Feature Metadata (Processed):
    (raw dtype, special dtypes):
    ('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    ('int', [])                  : 3 | ['season', 'weather', 'humidity']
    ('int', ['bool'])            : 2 | ['holiday', 'workingday']
    ('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    Plot summary of models saved to file: AutogluonModels/ag-20221222_142302/SummaryOfModels.html
    *** End of fit() summary ***
    




    {'model_types': {'KNeighborsUnif_BAG_L1': 'StackerEnsembleModel_KNN',
      'KNeighborsDist_BAG_L1': 'StackerEnsembleModel_KNN',
      'LightGBMXT_BAG_L1': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L1': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L1': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L1': 'StackerEnsembleModel_CatBoost',
      'ExtraTreesMSE_BAG_L1': 'StackerEnsembleModel_XT',
      'NeuralNetFastAI_BAG_L1': 'StackerEnsembleModel_NNFastAiTabular',
      'WeightedEnsemble_L2': 'WeightedEnsembleModel',
      'LightGBMXT_BAG_L2': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L2': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L2': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L2': 'StackerEnsembleModel_CatBoost',
      'WeightedEnsemble_L3': 'WeightedEnsembleModel'},
     'model_performance': {'KNeighborsUnif_BAG_L1': -101.54619908446061,
      'KNeighborsDist_BAG_L1': -84.12506123181602,
      'LightGBMXT_BAG_L1': -131.46090891834504,
      'LightGBM_BAG_L1': -131.054161598899,
      'RandomForestMSE_BAG_L1': -116.54429428704391,
      'CatBoost_BAG_L1': -130.58593674624476,
      'ExtraTreesMSE_BAG_L1': -124.58805258915959,
      'NeuralNetFastAI_BAG_L1': -140.47832330362775,
      'WeightedEnsemble_L2': -84.12506123181602,
      'LightGBMXT_BAG_L2': -60.370184054086195,
      'LightGBM_BAG_L2': -55.035679788291326,
      'RandomForestMSE_BAG_L2': -53.43189032247191,
      'CatBoost_BAG_L2': -56.0038772119669,
      'WeightedEnsemble_L3': -53.10995936403048},
     'model_best': 'WeightedEnsemble_L3',
     'model_paths': {'KNeighborsUnif_BAG_L1': 'AutogluonModels/ag-20221222_142302/models/KNeighborsUnif_BAG_L1/',
      'KNeighborsDist_BAG_L1': 'AutogluonModels/ag-20221222_142302/models/KNeighborsDist_BAG_L1/',
      'LightGBMXT_BAG_L1': 'AutogluonModels/ag-20221222_142302/models/LightGBMXT_BAG_L1/',
      'LightGBM_BAG_L1': 'AutogluonModels/ag-20221222_142302/models/LightGBM_BAG_L1/',
      'RandomForestMSE_BAG_L1': 'AutogluonModels/ag-20221222_142302/models/RandomForestMSE_BAG_L1/',
      'CatBoost_BAG_L1': 'AutogluonModels/ag-20221222_142302/models/CatBoost_BAG_L1/',
      'ExtraTreesMSE_BAG_L1': 'AutogluonModels/ag-20221222_142302/models/ExtraTreesMSE_BAG_L1/',
      'NeuralNetFastAI_BAG_L1': 'AutogluonModels/ag-20221222_142302/models/NeuralNetFastAI_BAG_L1/',
      'WeightedEnsemble_L2': 'AutogluonModels/ag-20221222_142302/models/WeightedEnsemble_L2/',
      'LightGBMXT_BAG_L2': 'AutogluonModels/ag-20221222_142302/models/LightGBMXT_BAG_L2/',
      'LightGBM_BAG_L2': 'AutogluonModels/ag-20221222_142302/models/LightGBM_BAG_L2/',
      'RandomForestMSE_BAG_L2': 'AutogluonModels/ag-20221222_142302/models/RandomForestMSE_BAG_L2/',
      'CatBoost_BAG_L2': 'AutogluonModels/ag-20221222_142302/models/CatBoost_BAG_L2/',
      'WeightedEnsemble_L3': 'AutogluonModels/ag-20221222_142302/models/WeightedEnsemble_L3/'},
     'model_fit_times': {'KNeighborsUnif_BAG_L1': 0.043096303939819336,
      'KNeighborsDist_BAG_L1': 0.04526114463806152,
      'LightGBMXT_BAG_L1': 71.6327292919159,
      'LightGBM_BAG_L1': 33.79589056968689,
      'RandomForestMSE_BAG_L1': 12.323580503463745,
      'CatBoost_BAG_L1': 199.24141025543213,
      'ExtraTreesMSE_BAG_L1': 6.103705883026123,
      'NeuralNetFastAI_BAG_L1': 59.96139693260193,
      'WeightedEnsemble_L2': 0.871553897857666,
      'LightGBMXT_BAG_L2': 71.353435754776,
      'LightGBM_BAG_L2': 29.513507604599,
      'RandomForestMSE_BAG_L2': 29.314504623413086,
      'CatBoost_BAG_L2': 44.53855633735657,
      'WeightedEnsemble_L3': 0.5538413524627686},
     'model_pred_times': {'KNeighborsUnif_BAG_L1': 0.04588627815246582,
      'KNeighborsDist_BAG_L1': 0.04770994186401367,
      'LightGBMXT_BAG_L1': 9.212330341339111,
      'LightGBM_BAG_L1': 1.2244658470153809,
      'RandomForestMSE_BAG_L1': 0.642890214920044,
      'CatBoost_BAG_L1': 0.1426374912261963,
      'ExtraTreesMSE_BAG_L1': 0.6372475624084473,
      'NeuralNetFastAI_BAG_L1': 0.5651810169219971,
      'WeightedEnsemble_L2': 0.0013611316680908203,
      'LightGBMXT_BAG_L2': 4.36469292640686,
      'LightGBM_BAG_L2': 0.49834251403808594,
      'RandomForestMSE_BAG_L2': 0.7646160125732422,
      'CatBoost_BAG_L2': 0.16947484016418457,
      'WeightedEnsemble_L3': 0.0016026496887207031},
     'num_bag_folds': 8,
     'max_stack_level': 3,
     'model_hyperparams': {'KNeighborsUnif_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'KNeighborsDist_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'LightGBMXT_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'ExtraTreesMSE_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'NeuralNetFastAI_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L2': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBMXT_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L3': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True}},
     'leaderboard':                      model   score_val  pred_time_val    fit_time  \
     0      WeightedEnsemble_L3  -53.109959      18.317078  558.420917   
     1   RandomForestMSE_BAG_L2  -53.431890      13.282965  412.461576   
     2          LightGBM_BAG_L2  -55.035680      13.016691  412.660578   
     3          CatBoost_BAG_L2  -56.003877      12.687824  427.685627   
     4        LightGBMXT_BAG_L2  -60.370184      16.883042  454.500507   
     5    KNeighborsDist_BAG_L1  -84.125061       0.047710    0.045261   
     6      WeightedEnsemble_L2  -84.125061       0.049071    0.916815   
     7    KNeighborsUnif_BAG_L1 -101.546199       0.045886    0.043096   
     8   RandomForestMSE_BAG_L1 -116.544294       0.642890   12.323581   
     9     ExtraTreesMSE_BAG_L1 -124.588053       0.637248    6.103706   
     10         CatBoost_BAG_L1 -130.585937       0.142637  199.241410   
     11         LightGBM_BAG_L1 -131.054162       1.224466   33.795891   
     12       LightGBMXT_BAG_L1 -131.460909       9.212330   71.632729   
     13  NeuralNetFastAI_BAG_L1 -140.478323       0.565181   59.961397   
     
         pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  \
     0                 0.001603           0.553841            3       True   
     1                 0.764616          29.314505            2       True   
     2                 0.498343          29.513508            2       True   
     3                 0.169475          44.538556            2       True   
     4                 4.364693          71.353436            2       True   
     5                 0.047710           0.045261            1       True   
     6                 0.001361           0.871554            2       True   
     7                 0.045886           0.043096            1       True   
     8                 0.642890          12.323581            1       True   
     9                 0.637248           6.103706            1       True   
     10                0.142637         199.241410            1       True   
     11                1.224466          33.795891            1       True   
     12                9.212330          71.632729            1       True   
     13                0.565181          59.961397            1       True   
     
         fit_order  
     0          14  
     1          12  
     2          11  
     3          13  
     4          10  
     5           2  
     6           9  
     7           1  
     8           5  
     9           7  
     10          6  
     11          4  
     12          3  
     13          8  }



### Create predictions from test dataset


```python
predictions = predictor.predict(test)
predictions.head()
```




    0    23.358217
    1    41.972752
    2    45.887352
    3    49.803349
    4    51.955547
    Name: count, dtype: float32



#### NOTE: Kaggle will reject the submission if we don't set everything to be > 0.


```python
# Describe the `predictions` series to see if there are any negative values
predictions.describe()
```




    count    6493.000000
    mean      100.752563
    std        89.666618
    min         3.069366
    25%        20.069902
    50%        64.100052
    75%       167.219009
    max       366.163910
    Name: count, dtype: float64




```python
# How many negative values do we have?
sum(n < 0 for n in predictions.values.flatten())
```




    0




```python
# Set them to zero
predictions[predictions < 0] = 0
```

### Set predictions to submission dataframe, save, and submit


```python
submission["count"] = predictions
submission.to_csv("submission.csv", index=False)
```


```python
!kaggle competitions submit -c bike-sharing-demand -f submission.csv -m "first raw submission"
```

    100% 188k/188k [00:00<00:00, 206kB/s]
    Successfully submitted to Bike Sharing Demand

#### View submission via the command line or in the web browser under the competition's page - `My Submissions`


```python
!kaggle competitions submissions -c bike-sharing-demand | tail -n +1 | head -n 6
```

    fileName        date                 description           status    publicScore  privateScore  
    --------------  -------------------  --------------------  --------  -----------  ------------  
    submission.csv  2022-12-22 07:02:43  first raw submission  complete  1.80014      1.80014       
    

#### Initial score of `?`

## Step 4: Exploratory Data Analysis and Creating an additional feature
* Any additional feature will do, but a great suggestion would be to separate out the datetime into hour, day, or month parts.


```python
# Create a histogram of all features to show the distribution of each one relative to the data. This is part of the exploritory data analysis
train.hist(figsize=(12,12))
```




    array([[<matplotlib.axes._subplots.AxesSubplot object at 0x7f3132f49610>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132f17820>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132ec6c40>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x7f3132ef40d0>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132ead460>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132e59790>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x7f3132e59880>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132e09cd0>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132def4c0>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x7f3132d998b0>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132d47c10>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132d741f0>]],
          dtype=object)




    
![png](output_44_1.png)
    



```python
# create a new feature
train["day"] = train["datetime"].dt.day
test["day"] = test["datetime"].dt.day

train["month"] = train["datetime"].dt.month
test["month"] = test["datetime"].dt.month

train["year"] = train["datetime"].dt.year
test["year"] = test["datetime"].dt.year

train["hour"] = train["datetime"].dt.hour
test["hour"] = test["datetime"].dt.hour
```


```python
train.tail()
```





  <div id="df-9ceb8ace-6d8e-42e8-b594-9a8c32dda19a">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>count</th>
      <th>day</th>
      <th>month</th>
      <th>year</th>
      <th>hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>10881</th>
      <td>2012-12-19 19:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>15.58</td>
      <td>19.695</td>
      <td>50</td>
      <td>26.0027</td>
      <td>336</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>19</td>
    </tr>
    <tr>
      <th>10882</th>
      <td>2012-12-19 20:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>57</td>
      <td>15.0013</td>
      <td>241</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>20</td>
    </tr>
    <tr>
      <th>10883</th>
      <td>2012-12-19 21:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>15.910</td>
      <td>61</td>
      <td>15.0013</td>
      <td>168</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>21</td>
    </tr>
    <tr>
      <th>10884</th>
      <td>2012-12-19 22:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>17.425</td>
      <td>61</td>
      <td>6.0032</td>
      <td>129</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>22</td>
    </tr>
    <tr>
      <th>10885</th>
      <td>2012-12-19 23:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.12</td>
      <td>16.665</td>
      <td>66</td>
      <td>8.9981</td>
      <td>88</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-9ceb8ace-6d8e-42e8-b594-9a8c32dda19a')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-9ceb8ace-6d8e-42e8-b594-9a8c32dda19a button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-9ceb8ace-6d8e-42e8-b594-9a8c32dda19a');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>




## Make category types for these so models know they are not just numbers
* AutoGluon originally sees these as ints, but in reality they are int representations of a category.
* Setting the dtype to category will classify these as categories in AutoGluon.


```python
train["season"] = train["season"].astype('category')
train["weather"] = train["weather"].astype('category')
test["season"] = test["season"].astype('category')
test["weather"] = test["weather"].astype('category')
```


```python
train.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10886 entries, 0 to 10885
    Data columns (total 14 columns):
     #   Column      Non-Null Count  Dtype         
    ---  ------      --------------  -----         
     0   datetime    10886 non-null  datetime64[ns]
     1   season      10886 non-null  category      
     2   holiday     10886 non-null  int64         
     3   workingday  10886 non-null  int64         
     4   weather     10886 non-null  category      
     5   temp        10886 non-null  float64       
     6   atemp       10886 non-null  float64       
     7   humidity    10886 non-null  int64         
     8   windspeed   10886 non-null  float64       
     9   count       10886 non-null  int64         
     10  day         10886 non-null  int64         
     11  month       10886 non-null  int64         
     12  year        10886 non-null  int64         
     13  hour        10886 non-null  int64         
    dtypes: category(2), datetime64[ns](1), float64(3), int64(8)
    memory usage: 1.0 MB
    


```python
# View are new feature
train.tail()
```





  <div id="df-cd7ab080-0c42-4976-9198-8db02ab6114e">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>count</th>
      <th>day</th>
      <th>month</th>
      <th>year</th>
      <th>hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>10881</th>
      <td>2012-12-19 19:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>15.58</td>
      <td>19.695</td>
      <td>50</td>
      <td>26.0027</td>
      <td>336</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>19</td>
    </tr>
    <tr>
      <th>10882</th>
      <td>2012-12-19 20:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>57</td>
      <td>15.0013</td>
      <td>241</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>20</td>
    </tr>
    <tr>
      <th>10883</th>
      <td>2012-12-19 21:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>15.910</td>
      <td>61</td>
      <td>15.0013</td>
      <td>168</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>21</td>
    </tr>
    <tr>
      <th>10884</th>
      <td>2012-12-19 22:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>17.425</td>
      <td>61</td>
      <td>6.0032</td>
      <td>129</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>22</td>
    </tr>
    <tr>
      <th>10885</th>
      <td>2012-12-19 23:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.12</td>
      <td>16.665</td>
      <td>66</td>
      <td>8.9981</td>
      <td>88</td>
      <td>19</td>
      <td>12</td>
      <td>2012</td>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-cd7ab080-0c42-4976-9198-8db02ab6114e')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-cd7ab080-0c42-4976-9198-8db02ab6114e button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-cd7ab080-0c42-4976-9198-8db02ab6114e');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
# View histogram of all features again now with the hour feature
train.hist(figsize=(12,12))
```




    array([[<matplotlib.axes._subplots.AxesSubplot object at 0x7f3132a9f130>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f31325d4820>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f313257ac40>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x7f31325aa0d0>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f313255bcd0>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132512370>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x7f3132512460>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f31324bcbe0>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f313249da00>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x7f3132455160>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f31323fe880>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x7f3132429fa0>]],
          dtype=object)




    
![png](output_51_1.png)
    



```python
#correlation matrix
train.corr()
```





  <div id="df-91800102-f98b-4982-8313-a4ed9617c224">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>holiday</th>
      <th>workingday</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>count</th>
      <th>day</th>
      <th>month</th>
      <th>year</th>
      <th>hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>holiday</th>
      <td>1.000000</td>
      <td>-0.250491</td>
      <td>0.000295</td>
      <td>-0.005215</td>
      <td>0.001929</td>
      <td>0.008409</td>
      <td>-0.005393</td>
      <td>-0.015877</td>
      <td>0.001731</td>
      <td>0.012021</td>
      <td>-0.000354</td>
    </tr>
    <tr>
      <th>workingday</th>
      <td>-0.250491</td>
      <td>1.000000</td>
      <td>0.029966</td>
      <td>0.024660</td>
      <td>-0.010880</td>
      <td>0.013373</td>
      <td>0.011594</td>
      <td>0.009829</td>
      <td>-0.003394</td>
      <td>-0.002482</td>
      <td>0.002780</td>
    </tr>
    <tr>
      <th>temp</th>
      <td>0.000295</td>
      <td>0.029966</td>
      <td>1.000000</td>
      <td>0.984948</td>
      <td>-0.064949</td>
      <td>-0.017852</td>
      <td>0.394454</td>
      <td>0.015551</td>
      <td>0.257589</td>
      <td>0.061226</td>
      <td>0.145430</td>
    </tr>
    <tr>
      <th>atemp</th>
      <td>-0.005215</td>
      <td>0.024660</td>
      <td>0.984948</td>
      <td>1.000000</td>
      <td>-0.043536</td>
      <td>-0.057473</td>
      <td>0.389784</td>
      <td>0.011866</td>
      <td>0.264173</td>
      <td>0.058540</td>
      <td>0.140343</td>
    </tr>
    <tr>
      <th>humidity</th>
      <td>0.001929</td>
      <td>-0.010880</td>
      <td>-0.064949</td>
      <td>-0.043536</td>
      <td>1.000000</td>
      <td>-0.318607</td>
      <td>-0.317371</td>
      <td>-0.011335</td>
      <td>0.204537</td>
      <td>-0.078606</td>
      <td>-0.278011</td>
    </tr>
    <tr>
      <th>windspeed</th>
      <td>0.008409</td>
      <td>0.013373</td>
      <td>-0.017852</td>
      <td>-0.057473</td>
      <td>-0.318607</td>
      <td>1.000000</td>
      <td>0.101369</td>
      <td>0.036157</td>
      <td>-0.150192</td>
      <td>-0.015221</td>
      <td>0.146631</td>
    </tr>
    <tr>
      <th>count</th>
      <td>-0.005393</td>
      <td>0.011594</td>
      <td>0.394454</td>
      <td>0.389784</td>
      <td>-0.317371</td>
      <td>0.101369</td>
      <td>1.000000</td>
      <td>0.019826</td>
      <td>0.166862</td>
      <td>0.260403</td>
      <td>0.400601</td>
    </tr>
    <tr>
      <th>day</th>
      <td>-0.015877</td>
      <td>0.009829</td>
      <td>0.015551</td>
      <td>0.011866</td>
      <td>-0.011335</td>
      <td>0.036157</td>
      <td>0.019826</td>
      <td>1.000000</td>
      <td>0.001974</td>
      <td>0.001800</td>
      <td>0.001132</td>
    </tr>
    <tr>
      <th>month</th>
      <td>0.001731</td>
      <td>-0.003394</td>
      <td>0.257589</td>
      <td>0.264173</td>
      <td>0.204537</td>
      <td>-0.150192</td>
      <td>0.166862</td>
      <td>0.001974</td>
      <td>1.000000</td>
      <td>-0.004932</td>
      <td>-0.006818</td>
    </tr>
    <tr>
      <th>year</th>
      <td>0.012021</td>
      <td>-0.002482</td>
      <td>0.061226</td>
      <td>0.058540</td>
      <td>-0.078606</td>
      <td>-0.015221</td>
      <td>0.260403</td>
      <td>0.001800</td>
      <td>-0.004932</td>
      <td>1.000000</td>
      <td>-0.004234</td>
    </tr>
    <tr>
      <th>hour</th>
      <td>-0.000354</td>
      <td>0.002780</td>
      <td>0.145430</td>
      <td>0.140343</td>
      <td>-0.278011</td>
      <td>0.146631</td>
      <td>0.400601</td>
      <td>0.001132</td>
      <td>-0.006818</td>
      <td>-0.004234</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-91800102-f98b-4982-8313-a4ed9617c224')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-91800102-f98b-4982-8313-a4ed9617c224 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-91800102-f98b-4982-8313-a4ed9617c224');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
#bike demand evolution
train.plot("datetime","count")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fee76618ee0>




    
![png](output_53_1.png)
    



```python
#bike demand evolution monthly 2011Y
train[train.year==2011].plot(x="month",y="count",)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fee7607a040>




    
![png](output_54_1.png)
    



```python
#bike demand evolution monthly 2012Y
train[train.year==2012].plot(x="month",y="count")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fee7610e100>




    
![png](output_55_1.png)
    


## Step 5: Rerun the model with the same settings as before, just with more features


```python
predictor_new_features = TabularPredictor(label="count", problem_type="regression", eval_metric="root_mean_squared_error").fit(
    train_data=train, time_limit=600, presets="best_quality"
)
```

    No path specified. Models will be saved in: "AutogluonModels/ag-20221222_145915/"
    Presets specified: ['best_quality']
    Stack configuration (auto_stack=True): num_stack_levels=1, num_bag_folds=8, num_bag_sets=20
    Beginning AutoGluon training ... Time limit = 600s
    AutoGluon will save models to "AutogluonModels/ag-20221222_145915/"
    AutoGluon Version:  0.6.1
    Python Version:     3.8.16
    Operating System:   Linux
    Platform Machine:   x86_64
    Platform Version:   #1 SMP Fri Aug 26 08:44:51 UTC 2022
    Train Data Rows:    10886
    Train Data Columns: 13
    Label Column: count
    Preprocessing data ...
    Using Feature Generators to preprocess the data ...
    Fitting AutoMLPipelineFeatureGenerator...
    	Available Memory:                    11564.43 MB
    	Train Data (Original)  Memory Usage: 0.98 MB (0.0% of available memory)
    	Inferring data type of each feature based on column values. Set feature_metadata_in to manually specify special dtypes of the features.
    	Stage 1 Generators:
    		Fitting AsTypeFeatureGenerator...
    			Note: Converting 3 features to boolean dtype as they only contain 2 unique values.
    	Stage 2 Generators:
    		Fitting FillNaFeatureGenerator...
    	Stage 3 Generators:
    		Fitting IdentityFeatureGenerator...
    		Fitting CategoryFeatureGenerator...
    			Fitting CategoryMemoryMinimizeFeatureGenerator...
    		Fitting DatetimeFeatureGenerator...
    /usr/local/lib/python3.8/dist-packages/autogluon/features/generators/datetime.py:59: FutureWarning: casting datetime64[ns, UTC] values to int64 with .astype(...) is deprecated and will raise in a future version. Use .view(...) instead.
      good_rows = series[~series.isin(bad_rows)].astype(np.int64)
    	Stage 4 Generators:
    		Fitting DropUniqueFeatureGenerator...
    	Types of features in original data (raw dtype, special dtypes):
    		('category', []) : 2 | ['season', 'weather']
    		('datetime', []) : 1 | ['datetime']
    		('float', [])    : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])      : 7 | ['holiday', 'workingday', 'humidity', 'day', 'month', ...]
    	Types of features in processed data (raw dtype, special dtypes):
    		('category', [])             : 2 | ['season', 'weather']
    		('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])                  : 4 | ['humidity', 'day', 'month', 'hour']
    		('int', ['bool'])            : 3 | ['holiday', 'workingday', 'year']
    		('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    	0.2s = Fit runtime
    	13 features in original data used to generate 17 features in processed data.
    	Train Data (Processed) Memory Usage: 1.1 MB (0.0% of available memory)
    Data preprocessing and feature engineering runtime = 0.3s ...
    AutoGluon will gauge predictive performance using evaluation metric: 'root_mean_squared_error'
    	This metric's sign has been flipped to adhere to being higher_is_better. The metric score can be multiplied by -1 to get the metric value.
    	To change this, specify the eval_metric parameter of Predictor()
    AutoGluon will fit 2 stack levels (L1 to L2) ...
    Fitting 11 L1 models ...
    Fitting model: KNeighborsUnif_BAG_L1 ... Training model for up to 399.7s of the 599.68s of remaining time.
    	-101.5462	 = Validation score   (-root_mean_squared_error)
    	0.05s	 = Training   runtime
    	0.05s	 = Validation runtime
    Fitting model: KNeighborsDist_BAG_L1 ... Training model for up to 399.53s of the 599.51s of remaining time.
    	-84.1251	 = Validation score   (-root_mean_squared_error)
    	0.05s	 = Training   runtime
    	0.05s	 = Validation runtime
    Fitting model: LightGBMXT_BAG_L1 ... Training model for up to 399.39s of the 599.37s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-34.387	 = Validation score   (-root_mean_squared_error)
    	104.93s	 = Training   runtime
    	11.42s	 = Validation runtime
    Fitting model: LightGBM_BAG_L1 ... Training model for up to 288.01s of the 488.0s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-33.9173	 = Validation score   (-root_mean_squared_error)
    	49.22s	 = Training   runtime
    	2.77s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L1 ... Training model for up to 232.82s of the 432.81s of remaining time.
    	-38.3808	 = Validation score   (-root_mean_squared_error)
    	15.3s	 = Training   runtime
    	0.66s	 = Validation runtime
    Fitting model: CatBoost_BAG_L1 ... Training model for up to 215.73s of the 415.71s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-34.1429	 = Validation score   (-root_mean_squared_error)
    	189.11s	 = Training   runtime
    	0.21s	 = Validation runtime
    Fitting model: ExtraTreesMSE_BAG_L1 ... Training model for up to 21.68s of the 221.67s of remaining time.
    	-38.4827	 = Validation score   (-root_mean_squared_error)
    	9.52s	 = Training   runtime
    	0.64s	 = Validation runtime
    Fitting model: NeuralNetFastAI_BAG_L1 ... Training model for up to 10.71s of the 210.7s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-124.3961	 = Validation score   (-root_mean_squared_error)
    	33.57s	 = Training   runtime
    	0.61s	 = Validation runtime
    Completed 1/20 k-fold bagging repeats ...
    Fitting model: WeightedEnsemble_L2 ... Training model for up to 360.0s of the 172.05s of remaining time.
    	-32.1387	 = Validation score   (-root_mean_squared_error)
    	0.58s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitting 9 L2 models ...
    Fitting model: LightGBMXT_BAG_L2 ... Training model for up to 171.43s of the 171.41s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-31.3638	 = Validation score   (-root_mean_squared_error)
    	36.0s	 = Training   runtime
    	1.02s	 = Validation runtime
    Fitting model: LightGBM_BAG_L2 ... Training model for up to 129.51s of the 129.49s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-30.6728	 = Validation score   (-root_mean_squared_error)
    	33.26s	 = Training   runtime
    	0.36s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L2 ... Training model for up to 91.22s of the 91.2s of remaining time.
    	-31.6192	 = Validation score   (-root_mean_squared_error)
    	34.9s	 = Training   runtime
    	0.75s	 = Validation runtime
    Fitting model: CatBoost_BAG_L2 ... Training model for up to 54.34s of the 54.33s of remaining time.
    	Fitting 8 child models (S1F1 - S1F8) | Fitting with ParallelLocalFoldFittingStrategy
    	-30.8709	 = Validation score   (-root_mean_squared_error)
    	59.62s	 = Training   runtime
    	0.19s	 = Validation runtime
    Completed 1/20 k-fold bagging repeats ...
    Fitting model: WeightedEnsemble_L3 ... Training model for up to 360.0s of the -10.59s of remaining time.
    	-30.4062	 = Validation score   (-root_mean_squared_error)
    	0.36s	 = Training   runtime
    	0.0s	 = Validation runtime
    AutoGluon training complete, total runtime = 611.01s ... Best model: "WeightedEnsemble_L3"
    TabularPredictor saved. To load, use: predictor = TabularPredictor.load("AutogluonModels/ag-20221222_145915/")
    


```python
predictor_new_features.fit_summary()
```

    *** Summary of fit() ***
    Estimated performance of each model:
                         model   score_val  pred_time_val    fit_time  pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  fit_order
    0      WeightedEnsemble_L3  -30.406158      18.732125  565.882731                0.001340           0.363033            3       True         14
    1          LightGBM_BAG_L2  -30.672815      16.770857  435.002951                0.356639          33.257779            2       True         11
    2          CatBoost_BAG_L2  -30.870852      16.601074  461.366352                0.186855          59.621181            2       True         13
    3        LightGBMXT_BAG_L2  -31.363830      17.438860  437.742588                1.024641          35.997416            2       True         10
    4   RandomForestMSE_BAG_L2  -31.619210      17.162649  436.643322                0.748431          34.898150            2       True         12
    5      WeightedEnsemble_L2  -32.138741      15.120193  359.190915                0.000996           0.584053            2       True          9
    6          LightGBM_BAG_L1  -33.917338       2.774429   49.219321                2.774429          49.219321            1       True          4
    7          CatBoost_BAG_L1  -34.142905       0.214352  189.114883                0.214352         189.114883            1       True          6
    8        LightGBMXT_BAG_L1  -34.387021      11.417783  104.927209               11.417783         104.927209            1       True          3
    9   RandomForestMSE_BAG_L1  -38.380819       0.661006   15.299405                0.661006          15.299405            1       True          5
    10    ExtraTreesMSE_BAG_L1  -38.482739       0.637595    9.521254                0.637595           9.521254            1       True          7
    11   KNeighborsDist_BAG_L1  -84.125061       0.051627    0.046045                0.051627           0.046045            1       True          2
    12   KNeighborsUnif_BAG_L1 -101.546199       0.049995    0.046259                0.049995           0.046259            1       True          1
    13  NeuralNetFastAI_BAG_L1 -124.396121       0.607431   33.570796                0.607431          33.570796            1       True          8
    Number of models trained: 14
    Types of models trained:
    {'StackerEnsembleModel_NNFastAiTabular', 'StackerEnsembleModel_RF', 'WeightedEnsembleModel', 'StackerEnsembleModel_KNN', 'StackerEnsembleModel_XT', 'StackerEnsembleModel_LGB', 'StackerEnsembleModel_CatBoost'}
    Bagging used: True  (with 8 folds)
    Multi-layer stack-ensembling used: True  (with 3 levels)
    Feature Metadata (Processed):
    (raw dtype, special dtypes):
    ('category', [])             : 2 | ['season', 'weather']
    ('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    ('int', [])                  : 4 | ['humidity', 'day', 'month', 'hour']
    ('int', ['bool'])            : 3 | ['holiday', 'workingday', 'year']
    ('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    Plot summary of models saved to file: AutogluonModels/ag-20221222_145915/SummaryOfModels.html
    *** End of fit() summary ***
    




    {'model_types': {'KNeighborsUnif_BAG_L1': 'StackerEnsembleModel_KNN',
      'KNeighborsDist_BAG_L1': 'StackerEnsembleModel_KNN',
      'LightGBMXT_BAG_L1': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L1': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L1': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L1': 'StackerEnsembleModel_CatBoost',
      'ExtraTreesMSE_BAG_L1': 'StackerEnsembleModel_XT',
      'NeuralNetFastAI_BAG_L1': 'StackerEnsembleModel_NNFastAiTabular',
      'WeightedEnsemble_L2': 'WeightedEnsembleModel',
      'LightGBMXT_BAG_L2': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L2': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L2': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L2': 'StackerEnsembleModel_CatBoost',
      'WeightedEnsemble_L3': 'WeightedEnsembleModel'},
     'model_performance': {'KNeighborsUnif_BAG_L1': -101.54619908446061,
      'KNeighborsDist_BAG_L1': -84.12506123181602,
      'LightGBMXT_BAG_L1': -34.38702114834055,
      'LightGBM_BAG_L1': -33.91733776595802,
      'RandomForestMSE_BAG_L1': -38.380819065321546,
      'CatBoost_BAG_L1': -34.1429053982246,
      'ExtraTreesMSE_BAG_L1': -38.48273859612585,
      'NeuralNetFastAI_BAG_L1': -124.39612068383626,
      'WeightedEnsemble_L2': -32.13874122253485,
      'LightGBMXT_BAG_L2': -31.36382955747378,
      'LightGBM_BAG_L2': -30.67281536084054,
      'RandomForestMSE_BAG_L2': -31.619209704011517,
      'CatBoost_BAG_L2': -30.87085199792365,
      'WeightedEnsemble_L3': -30.40615825836641},
     'model_best': 'WeightedEnsemble_L3',
     'model_paths': {'KNeighborsUnif_BAG_L1': 'AutogluonModels/ag-20221222_145915/models/KNeighborsUnif_BAG_L1/',
      'KNeighborsDist_BAG_L1': 'AutogluonModels/ag-20221222_145915/models/KNeighborsDist_BAG_L1/',
      'LightGBMXT_BAG_L1': 'AutogluonModels/ag-20221222_145915/models/LightGBMXT_BAG_L1/',
      'LightGBM_BAG_L1': 'AutogluonModels/ag-20221222_145915/models/LightGBM_BAG_L1/',
      'RandomForestMSE_BAG_L1': 'AutogluonModels/ag-20221222_145915/models/RandomForestMSE_BAG_L1/',
      'CatBoost_BAG_L1': 'AutogluonModels/ag-20221222_145915/models/CatBoost_BAG_L1/',
      'ExtraTreesMSE_BAG_L1': 'AutogluonModels/ag-20221222_145915/models/ExtraTreesMSE_BAG_L1/',
      'NeuralNetFastAI_BAG_L1': 'AutogluonModels/ag-20221222_145915/models/NeuralNetFastAI_BAG_L1/',
      'WeightedEnsemble_L2': 'AutogluonModels/ag-20221222_145915/models/WeightedEnsemble_L2/',
      'LightGBMXT_BAG_L2': 'AutogluonModels/ag-20221222_145915/models/LightGBMXT_BAG_L2/',
      'LightGBM_BAG_L2': 'AutogluonModels/ag-20221222_145915/models/LightGBM_BAG_L2/',
      'RandomForestMSE_BAG_L2': 'AutogluonModels/ag-20221222_145915/models/RandomForestMSE_BAG_L2/',
      'CatBoost_BAG_L2': 'AutogluonModels/ag-20221222_145915/models/CatBoost_BAG_L2/',
      'WeightedEnsemble_L3': 'AutogluonModels/ag-20221222_145915/models/WeightedEnsemble_L3/'},
     'model_fit_times': {'KNeighborsUnif_BAG_L1': 0.04625892639160156,
      'KNeighborsDist_BAG_L1': 0.04604458808898926,
      'LightGBMXT_BAG_L1': 104.92720890045166,
      'LightGBM_BAG_L1': 49.21932101249695,
      'RandomForestMSE_BAG_L1': 15.299405097961426,
      'CatBoost_BAG_L1': 189.11488270759583,
      'ExtraTreesMSE_BAG_L1': 9.521253824234009,
      'NeuralNetFastAI_BAG_L1': 33.570796251297,
      'WeightedEnsemble_L2': 0.5840530395507812,
      'LightGBMXT_BAG_L2': 35.997416257858276,
      'LightGBM_BAG_L2': 33.257779359817505,
      'RandomForestMSE_BAG_L2': 34.89815020561218,
      'CatBoost_BAG_L2': 59.62118101119995,
      'WeightedEnsemble_L3': 0.36303257942199707},
     'model_pred_times': {'KNeighborsUnif_BAG_L1': 0.04999518394470215,
      'KNeighborsDist_BAG_L1': 0.051627397537231445,
      'LightGBMXT_BAG_L1': 11.417783260345459,
      'LightGBM_BAG_L1': 2.7744290828704834,
      'RandomForestMSE_BAG_L1': 0.661005973815918,
      'CatBoost_BAG_L1': 0.21435165405273438,
      'ExtraTreesMSE_BAG_L1': 0.6375949382781982,
      'NeuralNetFastAI_BAG_L1': 0.6074309349060059,
      'WeightedEnsemble_L2': 0.0009961128234863281,
      'LightGBMXT_BAG_L2': 1.0246412754058838,
      'LightGBM_BAG_L2': 0.35663866996765137,
      'RandomForestMSE_BAG_L2': 0.7484309673309326,
      'CatBoost_BAG_L2': 0.18685531616210938,
      'WeightedEnsemble_L3': 0.0013403892517089844},
     'num_bag_folds': 8,
     'max_stack_level': 3,
     'model_hyperparams': {'KNeighborsUnif_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'KNeighborsDist_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'LightGBMXT_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'ExtraTreesMSE_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'NeuralNetFastAI_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L2': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBMXT_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L3': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True}},
     'leaderboard':                      model   score_val  pred_time_val    fit_time  \
     0      WeightedEnsemble_L3  -30.406158      18.732125  565.882731   
     1          LightGBM_BAG_L2  -30.672815      16.770857  435.002951   
     2          CatBoost_BAG_L2  -30.870852      16.601074  461.366352   
     3        LightGBMXT_BAG_L2  -31.363830      17.438860  437.742588   
     4   RandomForestMSE_BAG_L2  -31.619210      17.162649  436.643322   
     5      WeightedEnsemble_L2  -32.138741      15.120193  359.190915   
     6          LightGBM_BAG_L1  -33.917338       2.774429   49.219321   
     7          CatBoost_BAG_L1  -34.142905       0.214352  189.114883   
     8        LightGBMXT_BAG_L1  -34.387021      11.417783  104.927209   
     9   RandomForestMSE_BAG_L1  -38.380819       0.661006   15.299405   
     10    ExtraTreesMSE_BAG_L1  -38.482739       0.637595    9.521254   
     11   KNeighborsDist_BAG_L1  -84.125061       0.051627    0.046045   
     12   KNeighborsUnif_BAG_L1 -101.546199       0.049995    0.046259   
     13  NeuralNetFastAI_BAG_L1 -124.396121       0.607431   33.570796   
     
         pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  \
     0                 0.001340           0.363033            3       True   
     1                 0.356639          33.257779            2       True   
     2                 0.186855          59.621181            2       True   
     3                 1.024641          35.997416            2       True   
     4                 0.748431          34.898150            2       True   
     5                 0.000996           0.584053            2       True   
     6                 2.774429          49.219321            1       True   
     7                 0.214352         189.114883            1       True   
     8                11.417783         104.927209            1       True   
     9                 0.661006          15.299405            1       True   
     10                0.637595           9.521254            1       True   
     11                0.051627           0.046045            1       True   
     12                0.049995           0.046259            1       True   
     13                0.607431          33.570796            1       True   
     
         fit_order  
     0          14  
     1          11  
     2          13  
     3          10  
     4          12  
     5           9  
     6           4  
     7           6  
     8           3  
     9           5  
     10          7  
     11          2  
     12          1  
     13          8  }




```python
# Remember to set all negative values to zero
predictions_new_features = predictor_new_features.predict(test)
predictions_new_features.head()
```




    0    16.401878
    1    11.047426
    2    10.272551
    3     9.231811
    4     8.183758
    Name: count, dtype: float32




```python
sum(n < 0 for n in predictions_new_features.values.flatten())
```




    0




```python
submission_new_features = pd.read_csv("sampleSubmission.csv")
submission_new_features.head()
```





  <div id="df-3eb007b6-4c94-4187-b26b-41357000cbcc">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-20 00:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-20 01:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-20 02:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-20 03:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-20 04:00:00</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-3eb007b6-4c94-4187-b26b-41357000cbcc')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-3eb007b6-4c94-4187-b26b-41357000cbcc button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-3eb007b6-4c94-4187-b26b-41357000cbcc');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
# Same submitting predictions
submission_new_features["count"] = predictions_new_features
submission_new_features.to_csv("submission_new_features.csv", index=False)
```


```python
!kaggle competitions submit -c bike-sharing-demand -f submission_new_features.csv -m "new features"
```

    100% 188k/188k [00:03<00:00, 60.2kB/s]
    Successfully submitted to Bike Sharing Demand


```python
!kaggle competitions submissions -c bike-sharing-demand | tail -n +1 | head -n 6
```

    fileName                     date                 description           status    publicScore  privateScore  
    ---------------------------  -------------------  --------------------  --------  -----------  ------------  
    submission_new_features.csv  2022-12-22 15:15:42  new features          complete  0.64732      0.64732       
    submission.csv               2022-12-22 07:02:43  first raw submission  complete  1.80014      1.80014       
    

New Score of `0.64732`

## Step 6: Hyper parameter optimization
* There are many options for hyper parameter optimization.
* Options are to change the AutoGluon higher level parameters or the individual model hyperparameters.
* The hyperparameters of the models themselves that are in AutoGluon. Those need the `hyperparameter` and `hyperparameter_tune_kwargs` arguments.


```python
predictor_new_hpo = TabularPredictor(label="count", problem_type="regression", eval_metric="root_mean_squared_error").fit(
    train_data=train,num_gpus=1,time_limit=600, num_bag_folds=2, num_bag_sets=1, num_stack_levels=3, presets="best_quality"
)
```

    No path specified. Models will be saved in: "AutogluonModels/ag-20221229_085223/"
    Presets specified: ['best_quality']
    Stack configuration (auto_stack=True): num_stack_levels=3, num_bag_folds=2, num_bag_sets=1
    Beginning AutoGluon training ... Time limit = 600s
    AutoGluon will save models to "AutogluonModels/ag-20221229_085223/"
    AutoGluon Version:  0.6.1
    Python Version:     3.8.16
    Operating System:   Linux
    Platform Machine:   x86_64
    Platform Version:   #1 SMP Fri Aug 26 08:44:51 UTC 2022
    Train Data Rows:    10886
    Train Data Columns: 13
    Label Column: count
    Preprocessing data ...
    Using Feature Generators to preprocess the data ...
    Fitting AutoMLPipelineFeatureGenerator...
    	Available Memory:                    11654.42 MB
    	Train Data (Original)  Memory Usage: 0.98 MB (0.0% of available memory)
    	Inferring data type of each feature based on column values. Set feature_metadata_in to manually specify special dtypes of the features.
    	Stage 1 Generators:
    		Fitting AsTypeFeatureGenerator...
    			Note: Converting 3 features to boolean dtype as they only contain 2 unique values.
    	Stage 2 Generators:
    		Fitting FillNaFeatureGenerator...
    	Stage 3 Generators:
    		Fitting IdentityFeatureGenerator...
    		Fitting CategoryFeatureGenerator...
    			Fitting CategoryMemoryMinimizeFeatureGenerator...
    		Fitting DatetimeFeatureGenerator...
    /usr/local/lib/python3.8/dist-packages/autogluon/features/generators/datetime.py:59: FutureWarning: casting datetime64[ns, UTC] values to int64 with .astype(...) is deprecated and will raise in a future version. Use .view(...) instead.
      good_rows = series[~series.isin(bad_rows)].astype(np.int64)
    	Stage 4 Generators:
    		Fitting DropUniqueFeatureGenerator...
    	Types of features in original data (raw dtype, special dtypes):
    		('category', []) : 2 | ['season', 'weather']
    		('datetime', []) : 1 | ['datetime']
    		('float', [])    : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])      : 7 | ['holiday', 'workingday', 'humidity', 'day', 'month', ...]
    	Types of features in processed data (raw dtype, special dtypes):
    		('category', [])             : 2 | ['season', 'weather']
    		('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    		('int', [])                  : 4 | ['humidity', 'day', 'month', 'hour']
    		('int', ['bool'])            : 3 | ['holiday', 'workingday', 'year']
    		('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    	0.3s = Fit runtime
    	13 features in original data used to generate 17 features in processed data.
    	Train Data (Processed) Memory Usage: 1.1 MB (0.0% of available memory)
    Data preprocessing and feature engineering runtime = 0.38s ...
    AutoGluon will gauge predictive performance using evaluation metric: 'root_mean_squared_error'
    	This metric's sign has been flipped to adhere to being higher_is_better. The metric score can be multiplied by -1 to get the metric value.
    	To change this, specify the eval_metric parameter of Predictor()
    AutoGluon will fit 4 stack levels (L1 to L4) ...
    Fitting 11 L1 models ...
    Fitting model: KNeighborsUnif_BAG_L1 ... Training model for up to 199.82s of the 599.6s of remaining time.
    	-101.5462	 = Validation score   (-root_mean_squared_error)
    	0.07s	 = Training   runtime
    	0.05s	 = Validation runtime
    Fitting model: KNeighborsDist_BAG_L1 ... Training model for up to 198.86s of the 598.64s of remaining time.
    	-84.1251	 = Validation score   (-root_mean_squared_error)
    	0.04s	 = Training   runtime
    	0.04s	 = Validation runtime
    Fitting model: LightGBMXT_BAG_L1 ... Training model for up to 198.08s of the 597.85s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-38.4003	 = Validation score   (-root_mean_squared_error)
    	12.24s	 = Training   runtime
    	4.72s	 = Validation runtime
    Fitting model: LightGBM_BAG_L1 ... Training model for up to 179.6s of the 579.38s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-37.8543	 = Validation score   (-root_mean_squared_error)
    	4.7s	 = Training   runtime
    	1.98s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L1 ... Training model for up to 169.38s of the 569.16s of remaining time.
    	-38.3808	 = Validation score   (-root_mean_squared_error)
    	13.56s	 = Training   runtime
    	0.6s	 = Validation runtime
    Fitting model: CatBoost_BAG_L1 ... Training model for up to 153.9s of the 553.68s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-38.6748	 = Validation score   (-root_mean_squared_error)
    	188.64s	 = Training   runtime
    	0.1s	 = Validation runtime
    Fitting model: WeightedEnsemble_L2 ... Training model for up to 360.0s of the 360.63s of remaining time.
    	-34.6653	 = Validation score   (-root_mean_squared_error)
    	0.5s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitting 9 L2 models ...
    Fitting model: LightGBMXT_BAG_L2 ... Training model for up to 160.01s of the 360.09s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-32.4478	 = Validation score   (-root_mean_squared_error)
    	7.73s	 = Training   runtime
    	1.87s	 = Validation runtime
    Fitting model: LightGBM_BAG_L2 ... Training model for up to 144.06s of the 344.14s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-32.1581	 = Validation score   (-root_mean_squared_error)
    	3.04s	 = Training   runtime
    	0.29s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L2 ... Training model for up to 136.01s of the 336.09s of remaining time.
    	-33.2121	 = Validation score   (-root_mean_squared_error)
    	26.94s	 = Training   runtime
    	0.66s	 = Validation runtime
    Fitting model: CatBoost_BAG_L2 ... Training model for up to 107.12s of the 307.2s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-32.7764	 = Validation score   (-root_mean_squared_error)
    	77.44s	 = Training   runtime
    	0.07s	 = Validation runtime
    Fitting model: ExtraTreesMSE_BAG_L2 ... Training model for up to 25.57s of the 225.64s of remaining time.
    	-33.0188	 = Validation score   (-root_mean_squared_error)
    	8.73s	 = Training   runtime
    	0.65s	 = Validation runtime
    Fitting model: NeuralNetFastAI_BAG_L2 ... Training model for up to 15.61s of the 215.68s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-123.0861	 = Validation score   (-root_mean_squared_error)
    	14.07s	 = Training   runtime
    	0.23s	 = Validation runtime
    Fitting model: WeightedEnsemble_L3 ... Training model for up to 360.0s of the 197.13s of remaining time.
    	-31.4905	 = Validation score   (-root_mean_squared_error)
    	0.36s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitting 9 L3 models ...
    Fitting model: LightGBMXT_BAG_L3 ... Training model for up to 131.13s of the 196.73s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-33.0702	 = Validation score   (-root_mean_squared_error)
    	2.44s	 = Training   runtime
    	0.15s	 = Validation runtime
    Fitting model: LightGBM_BAG_L3 ... Training model for up to 124.4s of the 190.0s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-32.7074	 = Validation score   (-root_mean_squared_error)
    	2.5s	 = Training   runtime
    	0.07s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L3 ... Training model for up to 117.52s of the 183.12s of remaining time.
    	-32.6719	 = Validation score   (-root_mean_squared_error)
    	28.92s	 = Training   runtime
    	0.65s	 = Validation runtime
    Fitting model: CatBoost_BAG_L3 ... Training model for up to 86.61s of the 152.22s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-32.1764	 = Validation score   (-root_mean_squared_error)
    	21.75s	 = Training   runtime
    	0.03s	 = Validation runtime
    Fitting model: ExtraTreesMSE_BAG_L3 ... Training model for up to 60.9s of the 126.49s of remaining time.
    	-32.1955	 = Validation score   (-root_mean_squared_error)
    	8.82s	 = Training   runtime
    	0.63s	 = Validation runtime
    Fitting model: NeuralNetFastAI_BAG_L3 ... Training model for up to 50.84s of the 116.44s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-32.4416	 = Validation score   (-root_mean_squared_error)
    	30.9s	 = Training   runtime
    	0.43s	 = Validation runtime
    Fitting model: XGBoost_BAG_L3 ... Training model for up to 15.27s of the 80.87s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-32.9431	 = Validation score   (-root_mean_squared_error)
    	4.38s	 = Training   runtime
    	0.1s	 = Validation runtime
    Fitting model: NeuralNetTorch_BAG_L3 ... Training model for up to 6.37s of the 71.97s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	Time limit exceeded... Skipping NeuralNetTorch_BAG_L3.
    Fitting model: WeightedEnsemble_L4 ... Training model for up to 360.0s of the 65.3s of remaining time.
    	-31.8054	 = Validation score   (-root_mean_squared_error)
    	0.7s	 = Training   runtime
    	0.0s	 = Validation runtime
    Fitting 9 L4 models ...
    Fitting model: LightGBMXT_BAG_L4 ... Training model for up to 64.56s of the 64.55s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-33.3603	 = Validation score   (-root_mean_squared_error)
    	2.33s	 = Training   runtime
    	0.15s	 = Validation runtime
    Fitting model: LightGBM_BAG_L4 ... Training model for up to 58.29s of the 58.28s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-33.0747	 = Validation score   (-root_mean_squared_error)
    	2.22s	 = Training   runtime
    	0.07s	 = Validation runtime
    Fitting model: RandomForestMSE_BAG_L4 ... Training model for up to 51.5s of the 51.48s of remaining time.
    	-33.0329	 = Validation score   (-root_mean_squared_error)
    	30.43s	 = Training   runtime
    	0.65s	 = Validation runtime
    Fitting model: CatBoost_BAG_L4 ... Training model for up to 19.16s of the 19.15s of remaining time.
    	Fitting 2 child models (S1F1 - S1F2) | Fitting with ParallelLocalFoldFittingStrategy
    	-32.3676	 = Validation score   (-root_mean_squared_error)
    	13.43s	 = Training   runtime
    	0.05s	 = Validation runtime
    Fitting model: ExtraTreesMSE_BAG_L4 ... Training model for up to 1.51s of the 1.5s of remaining time.
    	-32.7769	 = Validation score   (-root_mean_squared_error)
    	9.42s	 = Training   runtime
    	0.63s	 = Validation runtime
    Fitting model: WeightedEnsemble_L5 ... Training model for up to 360.0s of the -9.19s of remaining time.
    	-32.2448	 = Validation score   (-root_mean_squared_error)
    	0.31s	 = Training   runtime
    	0.0s	 = Validation runtime
    AutoGluon training complete, total runtime = 610.24s ... Best model: "WeightedEnsemble_L3"
    TabularPredictor saved. To load, use: predictor = TabularPredictor.load("AutogluonModels/ag-20221229_085223/")
    


```python
predictor_new_hpo.fit_summary()
```

    *** Summary of fit() ***
    Estimated performance of each model:
                         model   score_val  pred_time_val    fit_time  pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  fit_order
    0      WeightedEnsemble_L3  -31.490541      11.013564  343.486627                0.000789           0.364502            3       True         14
    1      WeightedEnsemble_L4  -31.805362      13.096624  452.668988                0.001015           0.695664            4       True         22
    2          LightGBM_BAG_L2  -32.158077       7.768369  222.282520                0.288916           3.038737            2       True          9
    3          CatBoost_BAG_L3  -32.176387      11.278566  378.943502                0.034459          21.748844            3       True         18
    4     ExtraTreesMSE_BAG_L3  -32.195532      11.875780  366.013219                0.631673           8.818562            3       True         19
    5      WeightedEnsemble_L5  -32.244828      14.644859  510.501371                0.000981           0.311804            5       True         28
    6          CatBoost_BAG_L4  -32.367640      13.359462  470.343930                0.045899          13.427199            4       True         26
    7   NeuralNetFastAI_BAG_L3  -32.441562      11.677404  388.098731                0.433297          30.904074            3       True         20
    8        LightGBMXT_BAG_L2  -32.447820       9.345516  226.977215                1.866063           7.733432            2       True          8
    9   RandomForestMSE_BAG_L3  -32.671928      11.898486  386.118124                0.654379          28.923467            3       True         17
    10         LightGBM_BAG_L3  -32.707387      11.311616  359.696214                0.067509           2.501557            3       True         16
    11         CatBoost_BAG_L2  -32.776369       7.554275  296.682632                0.074822          77.438849            2       True         11
    12    ExtraTreesMSE_BAG_L4  -32.776883      13.945654  466.333123                0.632092           9.416392            4       True         27
    13          XGBoost_BAG_L3  -32.943142      11.341801  361.578377                0.097694           4.383719            3       True         21
    14    ExtraTreesMSE_BAG_L2  -33.018801       8.124661  227.969407                0.645207           8.725624            2       True         12
    15  RandomForestMSE_BAG_L4  -33.032919      13.965888  487.345977                0.652325          30.429245            4       True         25
    16       LightGBMXT_BAG_L3  -33.070235      11.394552  359.636509                0.150445           2.441851            3       True         15
    17         LightGBM_BAG_L4  -33.074724      13.388067  459.131936                0.074505           2.215205            4       True         24
    18  RandomForestMSE_BAG_L2  -33.212112       8.137768  246.185483                0.658314          26.941700            2       True         10
    19       LightGBMXT_BAG_L4  -33.360319      13.468158  459.249159                0.154596           2.332428            4       True         23
    20     WeightedEnsemble_L2  -34.665252       7.433873  219.677002                0.000949           0.498457            2       True          7
    21         LightGBM_BAG_L1  -37.854278       1.981085    4.695249                1.981085           4.695249            1       True          4
    22  RandomForestMSE_BAG_L1  -38.380819       0.601768   13.562908                0.601768          13.562908            1       True          5
    23       LightGBMXT_BAG_L1  -38.400253       4.715242   12.244923                4.715242          12.244923            1       True          3
    24         CatBoost_BAG_L1  -38.674841       0.097511  188.636190                0.097511         188.636190            1       True          6
    25   KNeighborsDist_BAG_L1  -84.125061       0.037318    0.039276                0.037318           0.039276            1       True          2
    26   KNeighborsUnif_BAG_L1 -101.546199       0.046529    0.065238                0.046529           0.065238            1       True          1
    27  NeuralNetFastAI_BAG_L2 -123.086106       7.710786  233.316316                0.231332          14.072533            2       True         13
    Number of models trained: 28
    Types of models trained:
    {'StackerEnsembleModel_XGBoost', 'StackerEnsembleModel_CatBoost', 'StackerEnsembleModel_KNN', 'WeightedEnsembleModel', 'StackerEnsembleModel_LGB', 'StackerEnsembleModel_RF', 'StackerEnsembleModel_XT', 'StackerEnsembleModel_NNFastAiTabular'}
    Bagging used: True  (with 2 folds)
    Multi-layer stack-ensembling used: True  (with 5 levels)
    Feature Metadata (Processed):
    (raw dtype, special dtypes):
    ('category', [])             : 2 | ['season', 'weather']
    ('float', [])                : 3 | ['temp', 'atemp', 'windspeed']
    ('int', [])                  : 4 | ['humidity', 'day', 'month', 'hour']
    ('int', ['bool'])            : 3 | ['holiday', 'workingday', 'year']
    ('int', ['datetime_as_int']) : 5 | ['datetime', 'datetime.year', 'datetime.month', 'datetime.day', 'datetime.dayofweek']
    Plot summary of models saved to file: AutogluonModels/ag-20221229_085223/SummaryOfModels.html
    *** End of fit() summary ***
    




    {'model_types': {'KNeighborsUnif_BAG_L1': 'StackerEnsembleModel_KNN',
      'KNeighborsDist_BAG_L1': 'StackerEnsembleModel_KNN',
      'LightGBMXT_BAG_L1': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L1': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L1': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L1': 'StackerEnsembleModel_CatBoost',
      'WeightedEnsemble_L2': 'WeightedEnsembleModel',
      'LightGBMXT_BAG_L2': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L2': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L2': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L2': 'StackerEnsembleModel_CatBoost',
      'ExtraTreesMSE_BAG_L2': 'StackerEnsembleModel_XT',
      'NeuralNetFastAI_BAG_L2': 'StackerEnsembleModel_NNFastAiTabular',
      'WeightedEnsemble_L3': 'WeightedEnsembleModel',
      'LightGBMXT_BAG_L3': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L3': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L3': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L3': 'StackerEnsembleModel_CatBoost',
      'ExtraTreesMSE_BAG_L3': 'StackerEnsembleModel_XT',
      'NeuralNetFastAI_BAG_L3': 'StackerEnsembleModel_NNFastAiTabular',
      'XGBoost_BAG_L3': 'StackerEnsembleModel_XGBoost',
      'WeightedEnsemble_L4': 'WeightedEnsembleModel',
      'LightGBMXT_BAG_L4': 'StackerEnsembleModel_LGB',
      'LightGBM_BAG_L4': 'StackerEnsembleModel_LGB',
      'RandomForestMSE_BAG_L4': 'StackerEnsembleModel_RF',
      'CatBoost_BAG_L4': 'StackerEnsembleModel_CatBoost',
      'ExtraTreesMSE_BAG_L4': 'StackerEnsembleModel_XT',
      'WeightedEnsemble_L5': 'WeightedEnsembleModel'},
     'model_performance': {'KNeighborsUnif_BAG_L1': -101.54619908446061,
      'KNeighborsDist_BAG_L1': -84.12506123181602,
      'LightGBMXT_BAG_L1': -38.400252724199824,
      'LightGBM_BAG_L1': -37.85427828032833,
      'RandomForestMSE_BAG_L1': -38.380819065321546,
      'CatBoost_BAG_L1': -38.67484065304253,
      'WeightedEnsemble_L2': -34.665251929182254,
      'LightGBMXT_BAG_L2': -32.44781984840242,
      'LightGBM_BAG_L2': -32.158077389835,
      'RandomForestMSE_BAG_L2': -33.21211207415796,
      'CatBoost_BAG_L2': -32.776368555933054,
      'ExtraTreesMSE_BAG_L2': -33.01880088535551,
      'NeuralNetFastAI_BAG_L2': -123.08610587499027,
      'WeightedEnsemble_L3': -31.49054084367785,
      'LightGBMXT_BAG_L3': -33.07023531944397,
      'LightGBM_BAG_L3': -32.70738654020615,
      'RandomForestMSE_BAG_L3': -32.67192792684222,
      'CatBoost_BAG_L3': -32.176386975317385,
      'ExtraTreesMSE_BAG_L3': -32.19553160256025,
      'NeuralNetFastAI_BAG_L3': -32.441561649542436,
      'XGBoost_BAG_L3': -32.94314169821678,
      'WeightedEnsemble_L4': -31.805362018631868,
      'LightGBMXT_BAG_L4': -33.36031949315862,
      'LightGBM_BAG_L4': -33.07472422267152,
      'RandomForestMSE_BAG_L4': -33.03291925235999,
      'CatBoost_BAG_L4': -32.36763972565433,
      'ExtraTreesMSE_BAG_L4': -32.77688303189304,
      'WeightedEnsemble_L5': -32.244827689932244},
     'model_best': 'WeightedEnsemble_L3',
     'model_paths': {'KNeighborsUnif_BAG_L1': 'AutogluonModels/ag-20221229_085223/models/KNeighborsUnif_BAG_L1/',
      'KNeighborsDist_BAG_L1': 'AutogluonModels/ag-20221229_085223/models/KNeighborsDist_BAG_L1/',
      'LightGBMXT_BAG_L1': 'AutogluonModels/ag-20221229_085223/models/LightGBMXT_BAG_L1/',
      'LightGBM_BAG_L1': 'AutogluonModels/ag-20221229_085223/models/LightGBM_BAG_L1/',
      'RandomForestMSE_BAG_L1': 'AutogluonModels/ag-20221229_085223/models/RandomForestMSE_BAG_L1/',
      'CatBoost_BAG_L1': 'AutogluonModels/ag-20221229_085223/models/CatBoost_BAG_L1/',
      'WeightedEnsemble_L2': 'AutogluonModels/ag-20221229_085223/models/WeightedEnsemble_L2/',
      'LightGBMXT_BAG_L2': 'AutogluonModels/ag-20221229_085223/models/LightGBMXT_BAG_L2/',
      'LightGBM_BAG_L2': 'AutogluonModels/ag-20221229_085223/models/LightGBM_BAG_L2/',
      'RandomForestMSE_BAG_L2': 'AutogluonModels/ag-20221229_085223/models/RandomForestMSE_BAG_L2/',
      'CatBoost_BAG_L2': 'AutogluonModels/ag-20221229_085223/models/CatBoost_BAG_L2/',
      'ExtraTreesMSE_BAG_L2': 'AutogluonModels/ag-20221229_085223/models/ExtraTreesMSE_BAG_L2/',
      'NeuralNetFastAI_BAG_L2': 'AutogluonModels/ag-20221229_085223/models/NeuralNetFastAI_BAG_L2/',
      'WeightedEnsemble_L3': 'AutogluonModels/ag-20221229_085223/models/WeightedEnsemble_L3/',
      'LightGBMXT_BAG_L3': 'AutogluonModels/ag-20221229_085223/models/LightGBMXT_BAG_L3/',
      'LightGBM_BAG_L3': 'AutogluonModels/ag-20221229_085223/models/LightGBM_BAG_L3/',
      'RandomForestMSE_BAG_L3': 'AutogluonModels/ag-20221229_085223/models/RandomForestMSE_BAG_L3/',
      'CatBoost_BAG_L3': 'AutogluonModels/ag-20221229_085223/models/CatBoost_BAG_L3/',
      'ExtraTreesMSE_BAG_L3': 'AutogluonModels/ag-20221229_085223/models/ExtraTreesMSE_BAG_L3/',
      'NeuralNetFastAI_BAG_L3': 'AutogluonModels/ag-20221229_085223/models/NeuralNetFastAI_BAG_L3/',
      'XGBoost_BAG_L3': 'AutogluonModels/ag-20221229_085223/models/XGBoost_BAG_L3/',
      'WeightedEnsemble_L4': 'AutogluonModels/ag-20221229_085223/models/WeightedEnsemble_L4/',
      'LightGBMXT_BAG_L4': 'AutogluonModels/ag-20221229_085223/models/LightGBMXT_BAG_L4/',
      'LightGBM_BAG_L4': 'AutogluonModels/ag-20221229_085223/models/LightGBM_BAG_L4/',
      'RandomForestMSE_BAG_L4': 'AutogluonModels/ag-20221229_085223/models/RandomForestMSE_BAG_L4/',
      'CatBoost_BAG_L4': 'AutogluonModels/ag-20221229_085223/models/CatBoost_BAG_L4/',
      'ExtraTreesMSE_BAG_L4': 'AutogluonModels/ag-20221229_085223/models/ExtraTreesMSE_BAG_L4/',
      'WeightedEnsemble_L5': 'AutogluonModels/ag-20221229_085223/models/WeightedEnsemble_L5/'},
     'model_fit_times': {'KNeighborsUnif_BAG_L1': 0.06523776054382324,
      'KNeighborsDist_BAG_L1': 0.0392763614654541,
      'LightGBMXT_BAG_L1': 12.244922637939453,
      'LightGBM_BAG_L1': 4.695249080657959,
      'RandomForestMSE_BAG_L1': 13.562907695770264,
      'CatBoost_BAG_L1': 188.63618969917297,
      'WeightedEnsemble_L2': 0.4984567165374756,
      'LightGBMXT_BAG_L2': 7.733431816101074,
      'LightGBM_BAG_L2': 3.0387368202209473,
      'RandomForestMSE_BAG_L2': 26.941699981689453,
      'CatBoost_BAG_L2': 77.43884921073914,
      'ExtraTreesMSE_BAG_L2': 8.725623607635498,
      'NeuralNetFastAI_BAG_L2': 14.072532892227173,
      'WeightedEnsemble_L3': 0.3645024299621582,
      'LightGBMXT_BAG_L3': 2.4418511390686035,
      'LightGBM_BAG_L3': 2.501556634902954,
      'RandomForestMSE_BAG_L3': 28.923466682434082,
      'CatBoost_BAG_L3': 21.748844385147095,
      'ExtraTreesMSE_BAG_L3': 8.818561792373657,
      'NeuralNetFastAI_BAG_L3': 30.90407371520996,
      'XGBoost_BAG_L3': 4.383719444274902,
      'WeightedEnsemble_L4': 0.6956641674041748,
      'LightGBMXT_BAG_L4': 2.332427501678467,
      'LightGBM_BAG_L4': 2.2152047157287598,
      'RandomForestMSE_BAG_L4': 30.429245471954346,
      'CatBoost_BAG_L4': 13.427198886871338,
      'ExtraTreesMSE_BAG_L4': 9.416391611099243,
      'WeightedEnsemble_L5': 0.31180381774902344},
     'model_pred_times': {'KNeighborsUnif_BAG_L1': 0.046529293060302734,
      'KNeighborsDist_BAG_L1': 0.03731822967529297,
      'LightGBMXT_BAG_L1': 4.715242147445679,
      'LightGBM_BAG_L1': 1.9810853004455566,
      'RandomForestMSE_BAG_L1': 0.6017680168151855,
      'CatBoost_BAG_L1': 0.09751057624816895,
      'WeightedEnsemble_L2': 0.0009489059448242188,
      'LightGBMXT_BAG_L2': 1.8660626411437988,
      'LightGBM_BAG_L2': 0.28891587257385254,
      'RandomForestMSE_BAG_L2': 0.6583142280578613,
      'CatBoost_BAG_L2': 0.07482171058654785,
      'ExtraTreesMSE_BAG_L2': 0.6452071666717529,
      'NeuralNetFastAI_BAG_L2': 0.23133206367492676,
      'WeightedEnsemble_L3': 0.0007886886596679688,
      'LightGBMXT_BAG_L3': 0.15044450759887695,
      'LightGBM_BAG_L3': 0.06750917434692383,
      'RandomForestMSE_BAG_L3': 0.65437912940979,
      'CatBoost_BAG_L3': 0.03445887565612793,
      'ExtraTreesMSE_BAG_L3': 0.6316728591918945,
      'NeuralNetFastAI_BAG_L3': 0.43329668045043945,
      'XGBoost_BAG_L3': 0.09769392013549805,
      'WeightedEnsemble_L4': 0.0010149478912353516,
      'LightGBMXT_BAG_L4': 0.15459609031677246,
      'LightGBM_BAG_L4': 0.07450461387634277,
      'RandomForestMSE_BAG_L4': 0.6523253917694092,
      'CatBoost_BAG_L4': 0.045899152755737305,
      'ExtraTreesMSE_BAG_L4': 0.6320915222167969,
      'WeightedEnsemble_L5': 0.0009806156158447266},
     'num_bag_folds': 2,
     'max_stack_level': 5,
     'model_hyperparams': {'KNeighborsUnif_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'KNeighborsDist_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'LightGBMXT_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L1': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L2': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBMXT_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'ExtraTreesMSE_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'NeuralNetFastAI_BAG_L2': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L3': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBMXT_BAG_L3': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L3': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L3': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L3': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'ExtraTreesMSE_BAG_L3': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'NeuralNetFastAI_BAG_L3': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'XGBoost_BAG_L3': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'WeightedEnsemble_L4': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBMXT_BAG_L4': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'LightGBM_BAG_L4': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'RandomForestMSE_BAG_L4': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'CatBoost_BAG_L4': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True},
      'ExtraTreesMSE_BAG_L4': {'use_orig_features': True,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True,
       'use_child_oof': True},
      'WeightedEnsemble_L5': {'use_orig_features': False,
       'max_base_models': 25,
       'max_base_models_per_type': 5,
       'save_bag_folds': True}},
     'leaderboard':                      model   score_val  pred_time_val    fit_time  \
     0      WeightedEnsemble_L3  -31.490541      11.013564  343.486627   
     1      WeightedEnsemble_L4  -31.805362      13.096624  452.668988   
     2          LightGBM_BAG_L2  -32.158077       7.768369  222.282520   
     3          CatBoost_BAG_L3  -32.176387      11.278566  378.943502   
     4     ExtraTreesMSE_BAG_L3  -32.195532      11.875780  366.013219   
     5      WeightedEnsemble_L5  -32.244828      14.644859  510.501371   
     6          CatBoost_BAG_L4  -32.367640      13.359462  470.343930   
     7   NeuralNetFastAI_BAG_L3  -32.441562      11.677404  388.098731   
     8        LightGBMXT_BAG_L2  -32.447820       9.345516  226.977215   
     9   RandomForestMSE_BAG_L3  -32.671928      11.898486  386.118124   
     10         LightGBM_BAG_L3  -32.707387      11.311616  359.696214   
     11         CatBoost_BAG_L2  -32.776369       7.554275  296.682632   
     12    ExtraTreesMSE_BAG_L4  -32.776883      13.945654  466.333123   
     13          XGBoost_BAG_L3  -32.943142      11.341801  361.578377   
     14    ExtraTreesMSE_BAG_L2  -33.018801       8.124661  227.969407   
     15  RandomForestMSE_BAG_L4  -33.032919      13.965888  487.345977   
     16       LightGBMXT_BAG_L3  -33.070235      11.394552  359.636509   
     17         LightGBM_BAG_L4  -33.074724      13.388067  459.131936   
     18  RandomForestMSE_BAG_L2  -33.212112       8.137768  246.185483   
     19       LightGBMXT_BAG_L4  -33.360319      13.468158  459.249159   
     20     WeightedEnsemble_L2  -34.665252       7.433873  219.677002   
     21         LightGBM_BAG_L1  -37.854278       1.981085    4.695249   
     22  RandomForestMSE_BAG_L1  -38.380819       0.601768   13.562908   
     23       LightGBMXT_BAG_L1  -38.400253       4.715242   12.244923   
     24         CatBoost_BAG_L1  -38.674841       0.097511  188.636190   
     25   KNeighborsDist_BAG_L1  -84.125061       0.037318    0.039276   
     26   KNeighborsUnif_BAG_L1 -101.546199       0.046529    0.065238   
     27  NeuralNetFastAI_BAG_L2 -123.086106       7.710786  233.316316   
     
         pred_time_val_marginal  fit_time_marginal  stack_level  can_infer  \
     0                 0.000789           0.364502            3       True   
     1                 0.001015           0.695664            4       True   
     2                 0.288916           3.038737            2       True   
     3                 0.034459          21.748844            3       True   
     4                 0.631673           8.818562            3       True   
     5                 0.000981           0.311804            5       True   
     6                 0.045899          13.427199            4       True   
     7                 0.433297          30.904074            3       True   
     8                 1.866063           7.733432            2       True   
     9                 0.654379          28.923467            3       True   
     10                0.067509           2.501557            3       True   
     11                0.074822          77.438849            2       True   
     12                0.632092           9.416392            4       True   
     13                0.097694           4.383719            3       True   
     14                0.645207           8.725624            2       True   
     15                0.652325          30.429245            4       True   
     16                0.150445           2.441851            3       True   
     17                0.074505           2.215205            4       True   
     18                0.658314          26.941700            2       True   
     19                0.154596           2.332428            4       True   
     20                0.000949           0.498457            2       True   
     21                1.981085           4.695249            1       True   
     22                0.601768          13.562908            1       True   
     23                4.715242          12.244923            1       True   
     24                0.097511         188.636190            1       True   
     25                0.037318           0.039276            1       True   
     26                0.046529           0.065238            1       True   
     27                0.231332          14.072533            2       True   
     
         fit_order  
     0          14  
     1          22  
     2           9  
     3          18  
     4          19  
     5          28  
     6          26  
     7          20  
     8           8  
     9          17  
     10         16  
     11         11  
     12         27  
     13         21  
     14         12  
     15         25  
     16         15  
     17         24  
     18         10  
     19         23  
     20          7  
     21          4  
     22          5  
     23          3  
     24          6  
     25          2  
     26          1  
     27         13  }




```python
predictions_hpo = predictor_new_hpo.predict(test)
predictions_hpo.head()
```




    0    17.045513
    1    11.393410
    2     9.331726
    3     7.929997
    4     7.117903
    Name: count, dtype: float32




```python
submission_hpo = pd.read_csv("sampleSubmission.csv")
submission_hpo.head()
```





  <div id="df-83752a13-5b1e-4aaa-bdde-063e57585799">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-20 00:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-20 01:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-20 02:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-20 03:00:00</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-20 04:00:00</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-83752a13-5b1e-4aaa-bdde-063e57585799')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-83752a13-5b1e-4aaa-bdde-063e57585799 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-83752a13-5b1e-4aaa-bdde-063e57585799');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
# Remember to set all negative values to zero
sum(n < 0 for n in predictions_hpo.values.flatten())
```




    0




```python
predictions_hpo[predictions_hpo < 0] = 0
```


```python
sum(n < 0 for n in predictions_hpo.values.flatten())
```




    0




```python

```


```python
# Same submitting predictions
submission_hpo["count"] = predictions_hpo
submission_hpo.to_csv("submission_new_hpo.csv", index=False)
```


```python
!kaggle competitions submit -c bike-sharing-demand -f submission_new_hpo.csv -m "new features with hyperparameters(1,1,3)"
```

    100% 188k/188k [00:02<00:00, 76.9kB/s]
    Successfully submitted to Bike Sharing Demand


```python
!kaggle competitions submissions -c bike-sharing-demand
```

    fileName                     date                 description                               status    publicScore  privateScore  
    ---------------------------  -------------------  ----------------------------------------  --------  -----------  ------------  
    submission_new_hpo.csv       2022-12-29 09:05:14  new features with hyperparameters(1,1,3)  complete  0.64038      0.64038       
    submission_new_hpo.csv       2022-12-29 08:50:02  new features with hyperparameters(3,1,3)  complete  0.62255      0.62255       
    submission_new_hpo.csv       2022-12-28 06:40:30  new features with hyperparameters(9,5,3)  complete  0.74931      0.74931       
    submission_new_hpo.csv       2022-12-28 06:39:11  new features with hyperparameters(5,1,1)  complete  0.74931      0.74931       
    submission_new_hpo.csv       2022-12-23 16:03:13  new features with hyperparameters(5,1,1)  complete  0.68468      0.68468       
    submission_new_hpo.csv       2022-12-23 15:37:43  new features with hyperparameters(7,1,3)  complete  0.68365      0.68365       
    submission_new_hpo.csv       2022-12-23 15:23:54  new features with hyperparameters(5,1,3)  complete  0.67858      0.67858       
    submission_new_hpo.csv       2022-12-23 14:01:12  new features with hyperparameters         complete  0.79443      0.79443       
    submission_new_features.csv  2022-12-22 15:15:42  new features                              complete  0.64732      0.64732       
    submission.csv               2022-12-22 07:02:43  first raw submission                      complete  1.80014      1.80014       
    

New Score of `0.62255`

## Step 7: Write a Report
### Refer to the markdown file for the full report
### Creating plots and table for report


```python
# Taking the top model score from each training run and creating a line plot to show improvement
# You can create these in the notebook and save them to PNG or use some other tool (e.g. google sheets, excel)
fig = pd.DataFrame(
    {
        "model": ["initial", "add_features", "hpo"],
        "score": [1.80014, 0.64732, 0.62255]
    }
).plot(x="model", y="score", figsize=(8, 6)).get_figure()
fig.savefig('model_train_score.png')
```


    
![png](output_80_0.png)
    



```python
# Take the 3 kaggle scores and creating a line plot to show improvement
fig = pd.DataFrame(
    {
        "test_eval": ["initial", "add_features", "hpo"],
        "score": [1.80014, 0.64732, 0.62255]
    }
).plot(x="test_eval", y="score", figsize=(8, 6)).get_figure()
fig.savefig('model_test_score.png')
```


    
![png](output_81_0.png)
    


### Hyperparameter table


```python
# The 3 hyperparameters we tuned with the kaggle score as the result
pd.DataFrame({
    "model": ["initial", "add_features", "hpo"],
    "model_used" : "WeightedEnsemble_L3",
    "num_bag_folds": [5, 1, 3],
    "num_bag_sets": [1, 1, 1],
    "num_stack_levels": [3, 3, 3],
    "score": [0.67858, 0.64037, 0.62255]
})
```





  <div id="df-0fa65948-2359-492f-a27e-7d0dc31047f2">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>model</th>
      <th>model_used</th>
      <th>num_bag_folds</th>
      <th>num_bag_sets</th>
      <th>num_stack_levels</th>
      <th>score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>initial</td>
      <td>WeightedEnsemble_L3</td>
      <td>5</td>
      <td>1</td>
      <td>3</td>
      <td>0.67858</td>
    </tr>
    <tr>
      <th>1</th>
      <td>add_features</td>
      <td>WeightedEnsemble_L3</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0.64037</td>
    </tr>
    <tr>
      <th>2</th>
      <td>hpo</td>
      <td>WeightedEnsemble_L3</td>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>0.62255</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-0fa65948-2359-492f-a27e-7d0dc31047f2')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-0fa65948-2359-492f-a27e-7d0dc31047f2 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-0fa65948-2359-492f-a27e-7d0dc31047f2');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>



